//#include "F28x_Project.h"
#include "base.h"

REAL	wXMUL(WORD x1, WORD x2, WORD x3 )
{
	if (x3==0) return 0;
	else return ((LONG)x1 * x2) / x3;
}

REAL	rXMUL(REAL x1, REAL x2, REAL x3 )
{
	if (x3==0) return 0;
	else return (x1 * x2) / x3;
}

void Delay(volatile Uint16 time)
{
    volatile Uint16   i;
    for (i = 0; i < time; i++) { ;}
}

void Delay_us(volatile Uint16 time_us)
{
    volatile Uint16      i;
    for (i = 0; i < time_us; i++) {
		Delay(5);						// 150Mhz=>10, 60Mhz=>5
   		}
}

void Delay_ms(volatile Uint16 time_ms)
{
    volatile Uint16  i;
    for (i = 0; i < time_ms; i++) {
		Delay_us(979);
	    }
}

void Delay_sec(volatile Uint16 time_sec)
{
    volatile Uint16  i;
    for (i = 0; i < time_sec; i++) {
		Delay_ms(1000);
	    }
}


/* --- ascii data to hex data conversion --- */
BYTE AscToHex (BYTE asc)
{
	BYTE hex;

	if (asc >= '0' && asc <= '9')
		hex = asc - '0';
	else if (asc >= 'A' && asc <= 'F')
		hex = asc - 'A' + 10;
	else if (asc >= 'a' && asc <= 'f')
		hex = asc - 'a' + 10;
	else
		hex = 0xff;
	return hex;
}

/* --- hex data to ascii data conversion --- */
BYTE HexToAsc (BYTE hex)
{
	BYTE asc;

	hex &= 0x0f;
//	if (hex >= 0 && hex <= 9)		//	DELETE	08.10.08	KKM
	if (hex <= 9)		//	08.10.08	KKM
		asc = hex + '0';
	else							/* only convert to Capital letter */
		asc = hex + 'A' - 10;
	return asc;
}

BYTE Asc2ToHex (BYTE *asc)
{
	return ((AscToHex(asc[0]) << 4) & 0xf0) + (AscToHex(asc[1]) & 0x0f);
}


void HexToAsc2 (BYTE hex, BYTE *asc)
{
/*	hex &= 0xff;*/
	asc[0] = HexToAsc(HI_NIBBLE(hex));
	asc[1] = HexToAsc(LO_NIBBLE(hex));
}

WORD Asc4ToHex (BYTE *asc)
{
	BYTE bHi = Asc2ToHex(asc);
	BYTE bLo = Asc2ToHex(asc + 2);

	return ((WORD)bHi << 8) + (WORD)bLo;
}

void HexToAsc4 (WORD hex, BYTE *asc)
{
/*	hex &= 0xff;*/
	BYTE bHi = HI_BYTE(hex);
	BYTE bLo = LO_BYTE(hex);

	asc[0] = HexToAsc(HI_NIBBLE(bHi));
	asc[1] = HexToAsc(LO_NIBBLE(bHi));
	asc[2] = HexToAsc(HI_NIBBLE(bLo));
	asc[3] = HexToAsc(LO_NIBBLE(bLo));
}

WORD    root (LONG x1)
{
	register WORD	out, shift;

	if (x1 == 0)
		return 0;

	out = 0x0000;
	shift = 0x8000;

	do {
		out |= shift;
		if((LONG)out*out > x1)
			out ^= shift;
	}
	while (shift >>= 1);

	return out;
}

/*--------------------------------------------------------------*/
/*		iV5 TMS320F28335 New Control Board						*/
/*		���� Call �Լ� ����										*/
/*		BSH 2009/02/10 Ver 3.00 Debug01							*/
/*--------------------------------------------------------------*/
/*------------------------------------------------------------------------------------*/
//	WORD	xmul( WORD x1, WORD x2, WORD x3 )
//			{ return ((LONG)x1 * x2) / x3; }
//	WORD	xdiv( LONG x1, WORD x2 )
//			{ return x1 / x2; }
//	SWORD	sxdiv (SLONG x1, SWORD x2)
//			{ return x1 / x2; }
//	WORD	xmod( WORD x1, WORD x2, WORD x3 )
//			{ return ((LONG)x1 * x2) % x3; }
//	SWORD   sxmul (SWORD x1, SWORD x2, SWORD x3)
//			{ return ((SLONG)x1 * x2) / x3; }
//
//	// JDZ
//	WORD	xdiv2 ( WORD x, WORD y, WORD z )
//			{ return ((x * y + z/2) / z ) ; }

WORD	xmul( WORD x1, WORD x2, WORD x3 )
{
	if (x3==0) return 0xffff;
	else return ((LONG)x1 * x2) / x3;
}

WORD	xdiv( LONG x1, WORD x2 )
{
	return x1 / x2;
}

SWORD	sxdiv (SLONG x1, SWORD x2)
{
	return ((SLONG)x1 / x2);
}

WORD	xmod( WORD x1, WORD x2, WORD x3 )
{
	return ((LONG)x1 * x2) % x3;
}

SWORD   sxmul (SWORD x1, SWORD x2, SWORD x3)
{
	return ((SLONG)x1 * x2) / x3;
}

WORD	xdiv2 ( WORD x, WORD y, WORD z )
{
	return (((LONG)x * y + z/2) / z ) ;
}




void AllPass_Filter (float *input, float *output, float *SamplingFrequency, float *f_grid, float *pastinput, float *pastoutput)
{
    float a1, b0, b1, w0;
    w0 = 2*PI*(*f_grid);
    a1 = (w0-2*(*SamplingFrequency))/(w0+2*(*SamplingFrequency));
    b0 = a1;
    b1 = 1;
    *output = (b0*(*input))+(b1*(*pastinput))+(a1*(*pastoutput));
    *pastoutput = *output;
    *pastinput = *input;
}
