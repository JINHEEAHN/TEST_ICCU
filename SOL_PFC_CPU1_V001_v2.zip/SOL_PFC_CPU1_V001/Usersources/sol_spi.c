//#include "F28x_Project.h"
#include "base.h"

#define SPI_BRR        5


WORD spi_test =0;
void InitSpi(void)
{
	spi_test ++;

	EALLOW;
	GpioCtrlRegs.GPBPUD.bit.GPIO58 		= 0;   				// Enable pull-up on GPIO58 (SPISIMOA)
	GpioCtrlRegs.GPBPUD.bit.GPIO60 		= 0;   				// Enable pull-up on GPIO60 (SPICLKA)
	GpioCtrlRegs.GPBPUD.bit.GPIO61 		= 0; 				// Enable pull-up on GPIO61 (SPISTEA)

	GpioCtrlRegs.GPBQSEL2.bit.GPIO58 	= 3; 				// Asynch input GPIO58 (SPISIMOA)
	GpioCtrlRegs.GPBQSEL2.bit.GPIO60 	= 3; 				// Asynch input GPIO60 (SPICLKA)
	GpioCtrlRegs.GPBQSEL2.bit.GPIO61 	= 3; 				// Asynch input GPIO61 (SPISTEA)

	GpioCtrlRegs.GPBGMUX2.bit.GPIO58 	= 3;				// MUX POSITION 15	SPISIMOA
	GpioCtrlRegs.GPBMUX2.bit.GPIO58 	= 3;				// Configure GPIO58 as SPISIMOA

	GpioCtrlRegs.GPBGMUX2.bit.GPIO60 	= 3;				// MUX POSITION 15	SPICLKA
	GpioCtrlRegs.GPBMUX2.bit.GPIO60 	= 3; 				// Configure GPIO71 as SPICLKA

	GpioCtrlRegs.GPBGMUX2.bit.GPIO61 	= 3;				// MUX POSITION 6
	GpioCtrlRegs.GPBMUX2.bit.GPIO61		= 3;				// Configure GPIO59 as SPISTEB
	EDIS;

	SpiaRegs.SPICCR.bit.SPISWRESET 		= 0; 				// Reset SPI

	SpiaRegs.SPICCR.all 				= 0x004F;	       	// Reset on, rising edge, 16-bit char bits
	SpiaRegs.SPICTL.all 				= 0x000E;    		// Enable master mode, normal phase,
//	SpiaRegs.SPISTS.all 				= 0x0000;

	SpiaRegs.SPIBRR.all 				= 0x0011;			// Buad rate, 50M/4 = 12.5Mbps

	SpiaRegs.SPIFFTX.all 				= 0xC021;			// Enable FIFO's, set TX FIFO level to 1
	SpiaRegs.SPIFFRX.all 				= 0x0021;			// Set RX FIFO level to 1
	SpiaRegs.SPIFFCT.all 				= 0x08;
	SpiaRegs.SPIPRI.all 				= 0x0011;

	SpiaRegs.SPICCR.bit.SPISWRESET 		= 1;				// Enable SPI
	SpiaRegs.SPIFFTX.bit.TXFIFO 		= 1;
	SpiaRegs.SPIFFRX.bit.RXFIFORESET 	= 1;
}

// DAC�� SPI �ʱ�ȭ
void InitSpi_DAC(void)
{

	SET_DAC_DATA0 = 0.;
	SET_DAC_SCALE0 = 1.;
	SET_VOLT_SCALE0 = 1.;
	SET_DAC_OFFSET0 = 2048;
	SET_DATA_TYPE0 = 1;

	SET_DAC_DATA1 = 0.;
	SET_DAC_SCALE1 = 1.;
	SET_VOLT_SCALE1 = 1.;
	SET_DAC_OFFSET1 = 2048;
	SET_DATA_TYPE1 = 1;

	SET_DAC_DATA2 = 0.;
	SET_DAC_SCALE2 = 1.;
	SET_VOLT_SCALE2 = 1.;
	SET_DAC_OFFSET2 = 2048;
	SET_DATA_TYPE2 = 1;

	SET_DAC_DATA3 = 0.;
	SET_DAC_SCALE3 = 1.;
	SET_VOLT_SCALE3 = 1.;
	SET_DAC_OFFSET3	 = 2048;
	SET_DATA_TYPE3 = 1;
}

void DA_OUT(void)
{
	if(SpiaRegs.SPIFFTX.bit.TXFFST == 0)
	{
		SET_DAC_SCALE0 = 204.7 / SET_VOLT_SCALE0;
		SET_DAC_SCALE1 = 204.7 / SET_VOLT_SCALE1;
		SET_DAC_SCALE2 = 204.7 / SET_VOLT_SCALE2;
		SET_DAC_SCALE3 = 204.7 / SET_VOLT_SCALE3;

		switch(SET_DATA_TYPE0)
		{
			case 0 :  SpiaRegs.SPITXBUF = ((unsigned int)(((*(float *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0) & 0x0FFF) | 0x8000;						break;
			case 1 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0) & 0x0FFF) | 0x8000;		break;
			case 2 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0) & 0x0FFF) | 0x8000;		break;
		}

		switch(SET_DATA_TYPE1)
		{
			case 0 :  SpiaRegs.SPITXBUF = ((unsigned int)(((*(float *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1) & 0x0FFF) | 0x9000;						break;
			case 1 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1) & 0x0FFF) | 0x9000;		break;
			case 2 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1) & 0x0FFF) | 0x9000;		break;
		}

		switch(SET_DATA_TYPE2)
		{
			case 0 :  SpiaRegs.SPITXBUF = ((unsigned int)(((*(float *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2) & 0x0FFF) | 0xA000;						break;
			case 1 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2) & 0x0FFF) | 0xA000;		break;
			case 2 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2) & 0x0FFF) | 0xA000;		break;
		}

		switch(SET_DATA_TYPE3)
		{
			case 0 :  SpiaRegs.SPITXBUF = ((unsigned int)(((*(float *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;						break;
			case 1 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;		break;
			case 2 :  SpiaRegs.SPITXBUF = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;		break;
		}
	}
}
