//#include "F28x_Project.h"
#include "base.h"

void InitUserGpio(void)
{
	EALLOW;
    // EVM GPIO 32 ~ 39 LED setting

    //GPIO0 - RELAY
    GpioCtrlRegs.GPADIR.bit.GPIO0      = 1;        //output
    GpioCtrlRegs.GPAPUD.bit.GPIO0      = 1;        //disable pull up
    GpioDataRegs.GPACLEAR.bit.GPIO0    = 1;        //RLY OFF

    GpioCtrlRegs.GPBDIR.bit.GPIO32      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO32      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO32    = 1;        //led1 off

    GpioCtrlRegs.GPBDIR.bit.GPIO33      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO33      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO33    = 0;        //led2 off

    GpioCtrlRegs.GPBDIR.bit.GPIO34      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO34      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO34    = 1;        //led1 off

    GpioCtrlRegs.GPBDIR.bit.GPIO35      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO35      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO35    = 0;        //led2 off

    GpioCtrlRegs.GPBDIR.bit.GPIO36      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO36      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO36    = 1;        //led1 off

    GpioCtrlRegs.GPBDIR.bit.GPIO37      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO37      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO37    = 0;        //led2 off

    GpioCtrlRegs.GPBDIR.bit.GPIO38      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO38      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO38    = 0;        //led2 off

    GpioCtrlRegs.GPBDIR.bit.GPIO39      = 1;        //output
    GpioCtrlRegs.GPBPUD.bit.GPIO39      = 1;        //disable pull up
    GpioDataRegs.GPBCLEAR.bit.GPIO39    = 0;        //led2 off

    //
    //////////// OCP, OVP, UVP, OVP
	//GPIO2 - FLT_AC_INT
//	GpioCtrlRegs.GPADIR.bit.GPIO2 		= 0;		// Input
//	GpioCtrlRegs.GPAPUD.bit.GPIO2 		= 0;		// Enable Pull up
//	GpioCtrlRegs.GPAQSEL1.bit.GPIO2 	= 3;		// Asynch input GPIO2

	//GPIO3 - FLT_AC_EXT
//    GpioCtrlRegs.GPADIR.bit.GPIO3       = 1;        // Input
//    GpioCtrlRegs.GPAPUD.bit.GPIO3       = 1;        // Enable Pull up
//    GpioCtrlRegs.GPAQSEL1.bit.GPIO3     = 3;        // Asynch input GPIO3
//    GpioDataRegs.GPASET.bit.GPIO3       = 1;

	//GPIO 19 - SW1
	GpioCtrlRegs.GPADIR.bit.GPIO19 		= 0;		// Input
	GpioCtrlRegs.GPAPUD.bit.GPIO19		= 0;		// Enable Pull up
	GpioCtrlRegs.GPAQSEL2.bit.GPIO19	= 3;		//Asynch input GPIO3

	//GPIO 69 - LED1
	GpioCtrlRegs.GPCDIR.bit.GPIO93 		= 1; 		//output
	GpioCtrlRegs.GPCPUD.bit.GPIO93 		= 1; 		//disable pull up
	GpioDataRegs.GPCCLEAR.bit.GPIO93 	= 1;		//led1 off

	//GPIO 41 - LED2
	GpioCtrlRegs.GPCDIR.bit.GPIO94 		= 1; 		//output
	GpioCtrlRegs.GPCPUD.bit.GPIO94 		= 1; 		//disable pull up
	GpioDataRegs.GPCCLEAR.bit.GPIO94 	= 0;		//led2 off


//    //GPIO77 - FLT PFC561
//    GpioCtrlRegs.GPCMUX1.bit.GPIO77     = 0;        // gpio ����
//    GpioCtrlRegs.GPCDIR.bit.GPIO77      = 0;        // Input
//    GpioCtrlRegs.GPCPUD.bit.GPIO77      = 1;        // Disable pull up
//    GpioCtrlRegs.GPCQSEL1.bit.GPIO77    = 3;        // Asynch input GPIO3
//
//    //GPIO78 - FLT PFC34
//    GpioCtrlRegs.GPCMUX1.bit.GPIO78     = 0;        // gpio ����
//    GpioCtrlRegs.GPCDIR.bit.GPIO78      = 0;        // Input
//    GpioCtrlRegs.GPCPUD.bit.GPIO78      = 1;        // Disable pull up
//    GpioCtrlRegs.GPCQSEL1.bit.GPIO78    = 3;        // Asynch input GPIO3
//
//    //GPIO79 - FLT PFC12
//    GpioCtrlRegs.GPCMUX1.bit.GPIO79     = 0;        // gpio ����
//    GpioCtrlRegs.GPCDIR.bit.GPIO79      = 0;        // Input
//    GpioCtrlRegs.GPCPUD.bit.GPIO79      = 1;        // Disable pull up
//    GpioCtrlRegs.GPCQSEL1.bit.GPIO79    = 3;        // Asynch input GPIO3


	//GPIO 91 - PWM_BUFFER_EN
    GpioCtrlRegs.GPCDIR.bit.GPIO91      = 1;        //output
    GpioCtrlRegs.GPCPUD.bit.GPIO91      = 1;        //disable pull up
    GpioDataRegs.GPCSET.bit.GPIO91 		= 1;		//PWM_Buffer Enable

    //GPIO 91 - PWM_BUFFER_EN
    GpioDataRegs.GPCSET.bit.GPIO91      = 1;        //PWM_Buffer Enable
    GpioCtrlRegs.GPCDIR.bit.GPIO91      = 1;        //output
    GpioCtrlRegs.GPCPUD.bit.GPIO91      = 0;

    //GPIO62_VLL_OVT
    GpioCtrlRegs.GPBMUX2.bit.GPIO62     = 0;         // gpio ����
    GpioCtrlRegs.GPBDIR.bit.GPIO62      = 0;        // Input
    GpioCtrlRegs.GPBPUD.bit.GPIO62      = 0;        // Enable Pull up
    GpioCtrlRegs.GPBQSEL2.bit.GPIO62    = 3;        // Asynch input GPIO3
    InputXbarRegs.INPUT1SELECT     = 62;  // input 1 Xbar --> TZ1

    //GPIO63_OVT_DC
    GpioCtrlRegs.GPBMUX2.bit.GPIO63     = 0;         // gpio ����
    GpioCtrlRegs.GPBDIR.bit.GPIO63      = 0;        // Input
    GpioCtrlRegs.GPBPUD.bit.GPIO63      = 0;        // Enable Pull up
    GpioCtrlRegs.GPBQSEL2.bit.GPIO63    = 3;        // Asynch input GPIO3
    InputXbarRegs.INPUT2SELECT     = 63;

    //GPIO64_OCT
    GpioCtrlRegs.GPCMUX1.bit.GPIO64     = 0;         // gpio ����
    GpioCtrlRegs.GPCDIR.bit.GPIO64      = 0;        // Input
    GpioCtrlRegs.GPCPUD.bit.GPIO64      = 0;        // Enable Pull up
    GpioCtrlRegs.GPCQSEL1.bit.GPIO64    = 3;        // Asynch input GPIO3
    InputXbarRegs.INPUT3SELECT     = 64;
	EDIS;

    EALLOW;
    GpioCtrlRegs.GPAPUD.bit.GPIO16 = 1;
    GpioCtrlRegs.GPAPUD.bit.GPIO17 = 1;

    GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 5;
    GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 5;

    GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 1;    // Configure GPIO31 as EQEP3I    // ADCINB3
    GpioCtrlRegs.GPAQSEL2.bit.GPIO31 = 0;   // Sync GPIO31 to SYSCLK  (EQEP3I)
    GpioCtrlRegs.GPAPUD.bit.GPIO31 = 1;    // Disable pull-up on GPIO31 (EQEP3I)
    EDIS;

	RLY_OFF;
}

void Input_XBarInit(void)
{
	/* Input-X Bar ���� ���� */
	EALLOW;
	InputXbarRegs.INPUT1SELECT= 62;		//INPUT_Xbar 1
	InputXbarRegs.INPUT2SELECT= 63;		//INPUT_Xbar 2
	InputXbarRegs.INPUT3SELECT= 64;		//INPUT_Xbar 3
	EDIS;
}

void EpwmXbar_Init(void)
{
	EALLOW;
	EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX0 = 0;			// TRIP4 MUX 0.0  = CMPSS1.CTRIPH refer to "Table 8-2. ePWM X-BAR Mux Configuration Table"
	EPwmXbarRegs.TRIP4MUX0TO15CFG.bit.MUX1 = 0;			// TRIP4 MUX 1.0  = CMPSS1.CTRIPL
	EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX0 = 1;			// Enable TRIP4 Mux0
	EPwmXbarRegs.TRIP4MUXENABLE.bit.MUX1 = 1;			// Enable TRIP4 Mux1
	EPwmXbarRegs.TRIPOUTINV.bit.TRIP4 = 0;				// 1 : drives active LOW output

	EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX4 = 0;			// TRIP5 MUX 0.0  = CMPSS3.CTRIPH refer to "Table 8-2. ePWM X-BAR Mux Configuration Table"
	EPwmXbarRegs.TRIP5MUX0TO15CFG.bit.MUX5 = 0;			// TRIP5 MUX 1.0  = CMPSS3.CTRIPL
	EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX4 = 1;			// Enable TRIP4 Mux0
	EPwmXbarRegs.TRIP5MUXENABLE.bit.MUX5 = 1;			// Enable TRIP4 Mux1
	EPwmXbarRegs.TRIPOUTINV.bit.TRIP5 = 0;				// 1 : drives active LOW output
	EDIS;
}
