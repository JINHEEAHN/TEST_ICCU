
#ifndef USERINCLUDES_SOL_CMPSS_H_
#define USERINCLUDES_SOL_CMPSS_H_

extern void InitCmpss(void);

#endif /* SOURCE_USER_HEADER_CMPSS_H_ */
