#ifndef USERINCLUDES_SOL_UTIL_H_
#define USERINCLUDES_SOL_UTIL_H_

void outputHandler (void);
void InputHandler (void);
void CPULedToggle(void);
void mainInit(void);
void SystemParameter(void);
void vari_reset(void);

/*------------------------------------------*/
/*      << 1st order Lowpass Filter >>      */
/*      out          1                      */
/*      ---   = ------------                */
/*      in       (1 + Tc*s)                 */
/*                                          */
/*                  Ts                      */
/*      alpha = -----------                 */
/*              (Ts + 2*Tc)                 */
/*		alpha�� (-)�� ���Ǿ� ����			*/
/*------------------------------------------*/
#define		LPF1(out, in, in_p, alpa)											\
						out = out - ((SLONG)in * alpa) - ((SLONG)in_p * alpa)			\
						+ 2 * ((SWORD)(out >> 16) * (SLONG)alpa);					\
						in_p  = in;

#define		GET_ALPHA(Tsamp, Tcutoff)	((SWORD)(-(Tsamp * (SLONG)65536L)/((SLONG)Tsamp + 2*((SLONG)Tcutoff))))		// 2006/02/28 KKY


#define   AlphaCalc(alpha, fc, Tsamp)                         		\
          	alpha = Tsamp/(Tsamp+ 1/fc *2.);

#define   LowPassFilter(out, in, in_old, alpha) {                	\
          	out += alpha*(in + in_old - 2.* out);            			\
            in_old = in;																					\
          }


/*---------------------------------------------------------------------------
        highpass filter
            alpha = 1./(k+1)
            k = Tc*2./Tsamp
---------------------------------------------------------------------------*/
#define		HighpassFilter(out, out_old, in, in_old, alpha) {         \
          	out_old += alpha*(in + in_old - 2.*out_old);    	\
            in_old = in;                                    	\
            out = in - out_old;			\
          }

#define AllPassFilter(input, output, SamplingFrequency, CutOffFrequency, pastinput, pastOutput)\
{\
	float a1, bo, b1, w0;\
	w0 = 2 * PI * CutOffFrequency;\
	a1 = (w0 - 2 * SamplingFrequency) / ( 2 * SamplingFrequency + w0);\
	bo = a1;\
	b1 = 1;\
	output = (bo * input) + (b1 * pastinput ) - (a1 * pastOutput );\
	pastOutput = output;\
	pastinput = input;\
}

#define ABC_TO_DQS(fa, fb, fc, fds, fqs)          \
				fds = fa ;                              \
				fqs = INV_SQRT3*(fb - fc) ;

#define	DQS_TO_DQE(SIN, COS, fds, fqs, fde, fqe)						\
       	fde =  SIN*fqs + COS*fds;	\
       	fqe =  COS*fqs - SIN*fds;


#define DQE_TO_DQS(SIN, COS, fde, fqe, fds, fqs)						\
				fds = -SIN*fqe + COS*fde;									\
				fqs =  COS*fqe + SIN*fde;

#define DQS_TO_ABC(fds, fqs, fa, fb, fc)          \
				fa = fds;                                                 \
				fb = -0.5*(fds - SQRT3*fqs);                            \
				fc = -fa - fb;


// ABC -> dqs
#define	ABC_2_DQS(fa, fb, fc, fd, dq) \
				fd = fa;	\
				fq = INV_SQRT3 * fa + 2. * INV_SQRT3

// dqs -> dqe
#define	DQS_2_DQE(SIN, COS, fds, fqs, fde, fqe) \
				fde = COS * fds + SIN * fqs; \
				fqe = -SIN* fds + COS * fqs;

// dqe -> dqs
#define DQE_2_DQS(sin, cos, fde, fqe, fds, fqs) \
				fds = COS * fde - SIN * fqe; \
				fqs = SIN * fde + COS * fqe;

// dqs -> abc
#define DQS_2_ABC(fds, fqs, fa, fb, fc) \
				fa = fd;	\
				fb = -0.5 * fds - SQRT3 * fqs;	\
				fc = -0.5 * fds + SQRT3 * fqs;


#define DEADT_COMP(Vd, Vs, Is, Iband, VDTComp)               		\
    			if((Vd > 0) && (Vs <= 0.) && (Is <= Iband)) 			\
    					Vd = -VDTComp; 										\
    			else if((Vd <= 0) && (Vs >= 0.) && (Is >= -Iband))		\
    					Vd =  VDTComp;

#define   DeadComp(Vdead, Vas, Ias, Iband, VDTComp)              	\
    	  if(Vas > 0)		{if(Ias > -Iband)Vdead =  (SWORD)VDTComp;}		\
    	  else 					{if(Ias <  Iband)Vdead = -(SWORD)VDTComp;}

#define	DTimeComp(Vd, Vs, Is, Iband, VDt)	\
			if(Vs > 0.) { if(Is > -Iband) Vd = VDt; } \
			else {				if(Is < Iband ) Vd = -VDt; }

#define MinMaxPwm(vas, vbs, vcs) {                              \
         	float fltmp, fltmp2;                              	\
                                                                   \
          fltmp2 = vcs-vas;                                	\
          fltmp  = (vas-vbs)*fltmp2>=0. ? vas :             	\
          ((vbs-vcs)*fltmp2>=0. ? vcs : vbs);              	\
          fltmp *= 0.5;                                    	\
          vas += fltmp;                                    	\
          vbs += fltmp;                                    	\
          vcs += fltmp;                                   	\
        	}

#define   AlphaCalc4Apf(alpha, fc, Tsamp)                         \
          	float wc = 0;														\
           	wc = PI2 * fc;																				\
           	alpha = (2. - (wc * Tsamp))/(2. + (wc * Tsamp));			\

#define		TSAMP_1MSEC			0.001
#define		TSAMP_10MSEC		0.01
#define		TSAMP_100MSEC		0.1
#define		TSAMP_1SEC			1.

#define		BitMask(bit)	(1L << (bit))

#define		BitSet(val, bit)												\
					((val) |= (LONG)BitMaskLONG(bit))

#define		BitClr(val, bit)												\
					((val) &= (LONG)(~BitMaskLONG(bit)))

#define		BitCopy(val, bit, bool)											\
					(bool) ? BitSetLONG(val, bit) : BitClrLONG(val, bit)
				
#define		BitTest(val, bit)												\
					(BOOL)(((LONG)(val) >> (bit)) & 1L)				

#define		BitMaskLONG(bit)	(1L << (bit))

#define		BitSetLONG(val, bit)												\
					((val) |= (LONG)BitMaskLONG(bit))

#define		BitClrLONG(val, bit)												\
					((val) &= (LONG)(~BitMaskLONG(bit)))

#define		BitCopyLONG(val, bit, bool)											\
					(bool) ? BitSetLONG(val, bit) : BitClrLONG(val, bit)
				
#define		BitTestLONG(val, bit)												\
					(BOOL)(((LONG)(val) >> (bit)) & 1L)

#define		BIT_LONG_63		BitMaskLONG(63)
#define		BIT_LONG_62		BitMaskLONG(62)
#define		BIT_LONG_61		BitMaskLONG(61)
#define		BIT_LONG_60		BitMaskLONG(60)
#define		BIT_LONG_59		BitMaskLONG(59)
#define		BIT_LONG_58		BitMaskLONG(58)
#define		BIT_LONG_57		BitMaskLONG(57)
#define		BIT_LONG_56		BitMaskLONG(56)
#define		BIT_LONG_55		BitMaskLONG(55)
#define		BIT_LONG_54		BitMaskLONG(54)
#define		BIT_LONG_53		BitMaskLONG(53)
#define		BIT_LONG_52		BitMaskLONG(52)
#define		BIT_LONG_51		BitMaskLONG(51)
#define		BIT_LONG_50		BitMaskLONG(50)
#define		BIT_LONG_49		BitMaskLONG(49)
#define		BIT_LONG_48		BitMaskLONG(48)
#define		BIT_LONG_47		BitMaskLONG(47)
#define		BIT_LONG_46		BitMaskLONG(46)
#define		BIT_LONG_45		BitMaskLONG(45)
#define		BIT_LONG_44		BitMaskLONG(44)
#define		BIT_LONG_43		BitMaskLONG(43)
#define		BIT_LONG_42		BitMaskLONG(42)
#define		BIT_LONG_41		BitMaskLONG(41)
#define		BIT_LONG_40		BitMaskLONG(40)
#define		BIT_LONG_39		BitMaskLONG(39)
#define		BIT_LONG_38		BitMaskLONG(38)
#define		BIT_LONG_37		BitMaskLONG(37)
#define		BIT_LONG_36		BitMaskLONG(36)
#define		BIT_LONG_35		BitMaskLONG(35)
#define		BIT_LONG_34		BitMaskLONG(34)
#define		BIT_LONG_33		BitMaskLONG(33)
#define		BIT_LONG_32		BitMaskLONG(32)
#define		BIT_LONG_31		BitMaskLONG(31)
#define		BIT_LONG_30		BitMaskLONG(30)
#define		BIT_LONG_29		BitMaskLONG(29)
#define		BIT_LONG_28		BitMaskLONG(28)
#define		BIT_LONG_27		BitMaskLONG(27)
#define		BIT_LONG_26		BitMaskLONG(26)
#define		BIT_LONG_25		BitMaskLONG(25)
#define		BIT_LONG_24		BitMaskLONG(24)
#define		BIT_LONG_23		BitMaskLONG(23)
#define		BIT_LONG_22		BitMaskLONG(22)
#define		BIT_LONG_21		BitMaskLONG(21)
#define		BIT_LONG_20		BitMaskLONG(20)
#define		BIT_LONG_19		BitMaskLONG(19)
#define		BIT_LONG_18		BitMaskLONG(18)
#define		BIT_LONG_17		BitMaskLONG(17)
#define		BIT_LONG_16		BitMaskLONG(16)
#define		BIT_LONG_15		BitMaskLONG(15)
#define		BIT_LONG_14		BitMaskLONG(14)
#define		BIT_LONG_13		BitMaskLONG(13)
#define		BIT_LONG_12		BitMaskLONG(12)
#define		BIT_LONG_11		BitMaskLONG(11)
#define		BIT_LONG_10		BitMaskLONG(10)
#define		BIT_LONG_9		BitMaskLONG(9)
#define		BIT_LONG_8		BitMaskLONG(8)
#define		BIT_LONG_7		BitMaskLONG(7)
#define		BIT_LONG_6		BitMaskLONG(6)
#define		BIT_LONG_5		BitMaskLONG(5)
#define		BIT_LONG_4		BitMaskLONG(4)
#define		BIT_LONG_3		BitMaskLONG(3)
#define		BIT_LONG_2		BitMaskLONG(2)
#define		BIT_LONG_1		BitMaskLONG(1)
#define		BIT_LONG_0		BitMaskLONG(0)
/*------------------------------------------------------------------------------------*/


/*----------------------------------------------*/
/*		BSH 2006/03/10 Ver 2.00 MAX6730			*/
/*----------------------------------------------*/
/*----------------------------------------------------------------------------------*/
#define		BitToggle(val, bit)													\
				((val) ^= BitMask(bit))
/*----------------------------------------------------------------------------------*/

#define		BIT_15		BitMask(15)
#define		BIT_14		BitMask(14)
#define		BIT_13		BitMask(13)
#define		BIT_12		BitMask(12)
#define		BIT_11		BitMask(11)
#define		BIT_10		BitMask(10)
#define		BIT_9		BitMask(9)
#define		BIT_8		BitMask(8)
#define		BIT_7		BitMask(7)
#define		BIT_6		BitMask(6)
#define		BIT_5		BitMask(5)
#define		BIT_4		BitMask(4)
#define		BIT_3		BitMask(3)
#define		BIT_2		BitMask(2)
#define		BIT_1		BitMask(1)
#define		BIT_0		BitMask(0)


#define	HI_NIBBLE(data)	((BYTE)((data) >> 4))
#define	LO_NIBBLE(data)	((BYTE)((data) & 0x0F))

#define	HI_BYTE(data)		((BYTE)(((data) >> 8) & 0xFF))
#define	LO_BYTE(data)		((BYTE)((data) & 0xFF))

#define	HI_WORD(data)		((WORD)(((data) >> 16) & 0xFFFF))
#define	LO_WORD(data)		((WORD)((data) & 0xFFFF))

#define	MAKE_WORD(hi, lo) (WORD)(((WORD)(LO_BYTE(hi)) << 8) + (lo & 0xFF))
#define	MAKE_LONG(hi, lo) (LONG)(((LONG)(LO_WORD(hi)) << 16) + (lo & 0xFFFF))

#define	SIZE_OF_ARRAY(x)	(sizeof(x)/sizeof(x[0]))
#define	SIZE_OF_ARRAY_COLUMN(x)	(sizeof(x)/sizeof(x[0]))
#define	SIZE_OF_ARRAY_ROW(x)	(sizeof(x[0])/sizeof(x[0][0]))

#ifndef max
	#define max(a,b)		(((a) > (b)) ? (a) : (b))
#endif

#ifndef min
	#define min(a,b)		(((a) < (b)) ? (a) : (b))
#endif

#define	ABS(x)				((x) >= 0 ? (x) : -(x))
#define	ABS_W(x)			((x) > 0 ? (x) : -(x))		//	08.10.08	KKM
#define	FABS(x)				((x) >= 0. ? (x) : -(x))
#define	DELTA(a,b)			(((a) > (b)) ? (a)-(b) : (b)-(a))
#define	SIGN(x)				((x) >= 0 ? 1 : 0)
#define	MAKE_SIGNED(a, x)	((a) ? (x) : -(x))
#define	LIMIT(x, lo, hi)	if    ((x) > (hi)) x = hi;			\
							else if ((x) < (lo)) x = lo;

/*--------------------------------------------------------------*/
/*		iV5 TMS320F28335 New Control Board						*/
/*		BSH 2008/09/11 Ver 3.00 Debug01							*/
/*--------------------------------------------------------------*/
/*------------------------------------------------------------------------------------*/
#define	LIMIT_H(x, hi)		if      ((x) > (hi)) x = hi;
/*------------------------------------------------------------------------------------*/
	
#define	BOUND(x, hi)		LIMIT(x, -(hi), hi)
#define Bound3X(in,lim)   ((in > (lim)) ? (lim) : ((in < -(lim)) ? -(lim) : in))
#define	BOUND_PI(x)			((x)+(((x)>PI)?(-2.*PI):((x)<(-PI))?(2.*PI): 0.))


#define     AbcDqs(fa, fb, fc, fds, fqs)                              \
			fds = (2.*fa - fb - fc)/3. ;                              \
			fqs = INV_SQRT3*(fb - fc) ;

/*---------------------------------------------------------------------------
        stat. dq --> sync. dq
---------------------------------------------------------------------------*/
#define     DqsDqe(SIN, COS, fds, fqs, fde, fqe)						\
            	fqe =  COS*fqs - SIN*fds;			                  	\
              fde =  SIN*fqs + COS*fds;

/*---------------------------------------------------------------------------
        sync. dq --> stat. dq
---------------------------------------------------------------------------*/
#define     DqeDqs(SIN, COS, fde, fqe, fds, fqs)						\
            	fqs =  COS*fqe + SIN*fde;                       		\
                fds = -SIN*fqe + COS*fde;

// BSH 2002/09/12 Auto-tuning
#define     DqsAbc(fds, fqs, fa, fb, fc)                              \
			fa = fds;                                                 \
			fb = (-0.5)*(fds - SQRT3*fqs);                            \
			fc = (-0.5)*(fds + SQRT3*fqs);


extern REAL	wXMUL(WORD x1, WORD x2, WORD x3 );
extern REAL	rXMUL(REAL x1, REAL x2, REAL x3 );
extern void Delay(volatile Uint16 time);
extern void Delay_us(volatile Uint16 time_us);
extern void Delay_ms(volatile Uint16 time_ms);
extern void Delay_sec(volatile Uint16 time_sec);
 /* --- ascii data to hex data conversion --- */
extern BYTE AscToHex (BYTE asc);
 /* --- hex data to ascii data conversion --- */
extern BYTE HexToAsc (BYTE hex);
extern BYTE Asc2ToHex (BYTE *asc);
extern void HexToAsc2 (BYTE hex, BYTE *asc);
extern WORD Asc4ToHex (BYTE *asc);
extern void HexToAsc4 (WORD hex, BYTE *asc);
extern WORD    root (LONG x1);
extern WORD	xmul( WORD x1, WORD x2, WORD x3 );
extern WORD	xdiv( LONG x1, WORD x2 );
extern SWORD	sxdiv (SLONG x1, SWORD x2);
extern WORD	xmod( WORD x1, WORD x2, WORD x3 );
extern SWORD   sxmul (SWORD x1, SWORD x2, SWORD x3);
extern WORD	xdiv2 ( WORD x, WORD y, WORD z );

extern void AllPass_Filter (float *input, float *output, float *SamplingFrequency, float *f_grid, float *pastinput, float *pastoutput7);



#endif



