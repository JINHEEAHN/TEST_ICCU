
#ifndef USERINCLUDES_SOL_RESO_H_
#define USERINCLUDES_SOL_RESO_H_

typedef struct
{
	REAL		Wh;					// 1
	REAL		Kr;					// 2
	REAL		Cr1;				// 3
	REAL		Cr2;				// 4
	REAL		Cr3;				// 5
	REAL		Kt1;				// 6
	REAL		Kt2;				// 7
}rCOEFF_GAIN;

typedef struct
{
	REAL		Wh;					// 1
	REAL		Kr;					// 2
	REAL		Cr1;				// 3
	REAL		Cr2;				// 4
	REAL		Cr3;				// 5
	REAL		Kt1;				// 6
	REAL		Kt2;				// 7
	REAL		delayComp;			// 8
	REAL		Zt;					// 9
	REAL		Pt;					// 10
	REAL		Kc;					// 11
	REAL		K1;					// 12
	REAL		K2;					// 13
	REAL		K3;					// 14
	REAL		Ref;				// 15
	REAL		RefOld;				// 16
	REAL		Out;				// 17
	REAL		OutOld;				// 18
	REAL		OutOld1;			// 19
	REAL		OutOld2;			// 20
	REAL		ErrOld1;			// 21
	REAL		ErrOld2;			// 22
	
}rCOEFF;
/*
extern	rCOEFF_GAIN	rCoffHar3ThGain;
extern	rCOEFF_GAIN	rCoffHar5ThGain;
extern	rCOEFF_GAIN	rCoffHar7ThGain;
extern	rCOEFF_GAIN	rCoffHar9ThGain;
extern	rCOEFF_GAIN	rCoffHar11ThGain;
extern	rCOEFF_GAIN	rCoffHar13ThGain;
rCOEFF_GAIN	rCoffHar3ThGain;
rCOEFF_GAIN	rCoffHar5ThGain;
rCOEFF_GAIN	rCoffHar7ThGain;
rCOEFF_GAIN	rCoffHar9ThGain;
rCOEFF_GAIN	rCoffHar11ThGain;
rCOEFF_GAIN	rCoffHar13ThGain;

extern	rCOEFF	rCoffHarmonic3Th;
extern	rCOEFF	rCoffHarmonic5Th;
extern	rCOEFF	rCoffHarmonic7Th;
extern	rCOEFF	rCoffHarmonic9Th;
extern	rCOEFF	rCoffHarmonic11Th;
extern	rCOEFF	rCoffHarmonic13Th;
rCOEFF	rCoffHarmonic3Th;
rCOEFF	rCoffHarmonic5Th;
rCOEFF	rCoffHarmonic7Th;
rCOEFF	rCoffHarmonic9Th;
rCOEFF	rCoffHarmonic11Th;
rCOEFF	rCoffHarmonic13Th;

//extern rCOEFF	rCoffHarmonicR3Th;
//extern rCOEFF	rCoffHarmonicS3Th;
//extern rCOEFF	rCoffHarmonicT3Th;
//rCOEFF rCoffHarmonicR3Th;
//rCOEFF rCoffHarmonicS3Th;
//rCOEFF rCoffHarmonicT3Th;

extern rCOEFF	rCoffHarmonicR13Th;
extern rCOEFF	rCoffHarmonicS13Th;
extern rCOEFF	rCoffHarmonicT13Th;
rCOEFF rCoffHarmonicR13Th;
rCOEFF rCoffHarmonicS13Th;
rCOEFF rCoffHarmonicT13Th;

extern rCOEFF	rCoffHarmonicR5Th;
extern rCOEFF	rCoffHarmonicS5Th;
extern rCOEFF	rCoffHarmonicT5Th;
rCOEFF rCoffHarmonicR5Th;
rCOEFF rCoffHarmonicS5Th;
rCOEFF rCoffHarmonicT5Th;

extern rCOEFF	rCoffHarmonicR7Th;
extern rCOEFF	rCoffHarmonicS7Th;
extern rCOEFF	rCoffHarmonicT7Th;
rCOEFF rCoffHarmonicR7Th;
rCOEFF rCoffHarmonicS7Th;
rCOEFF rCoffHarmonicT7Th;

extern rCOEFF	rCoffHarmonicR9Th;
extern rCOEFF	rCoffHarmonicS9Th;
extern rCOEFF	rCoffHarmonicT9Th;
rCOEFF rCoffHarmonicR9Th;
rCOEFF rCoffHarmonicS9Th;
rCOEFF rCoffHarmonicT9Th;

extern rCOEFF	rCoffHarmonicR11Th;
extern rCOEFF	rCoffHarmonicS11Th;
extern rCOEFF	rCoffHarmonicT11Th;
rCOEFF rCoffHarmonicR11Th;
rCOEFF rCoffHarmonicS11Th;
rCOEFF rCoffHarmonicT11Th;

extern	rCOEFF_GAIN	rCoffHar13ThGain;
extern	rCOEFF_GAIN	rCoffHar5ThGain;
extern	rCOEFF_GAIN	rCoffHar7ThGain;
extern	rCOEFF_GAIN	rCoffHar9ThGain;
extern	rCOEFF_GAIN	rCoffHar11ThGain;
//extern	rCOEFF_GAIN	rCoffHar3ThGain;
//rCOEFF_GAIN	rCoffHar3ThGain;
rCOEFF_GAIN	rCoffHar13ThGain;
rCOEFF_GAIN	rCoffHar5ThGain;
rCOEFF_GAIN	rCoffHar7ThGain;
rCOEFF_GAIN	rCoffHar9ThGain;
rCOEFF_GAIN	rCoffHar11ThGain;
*/


/*
extern rCOEFF	rCoff5thHarmonicId;
extern rCOEFF	rCoff5thHarmonicIq;
rCOEFF rCoff5thHarmonicId = {0, 1, 0, 0, 0, 0, 0, 1.5, 0, 0,
													 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
												 	 0, 0 };
rCOEFF rCoff5thHarmonicIq = {0, 1, 0, 0, 0, 0, 0, 1.5, 0, 0,
													 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
												 	 0, 0 };
extern rCOEFF	rCoff7thHarmonicId;
extern rCOEFF	rCoff7thHarmonicIq;
rCOEFF rCoff7thHarmonicId = {0, 1, 0, 0, 0, 0, 0, 1.5, 0, 0,
													 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
												 	 0, 0 };
rCOEFF rCoff7thHarmonicIq = {0, 1, 0, 0, 0, 0, 0, 1.5, 0, 0,
													 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
												 	 0, 0 };
*/

void InitResoVariable(rCOEFF * eff);
void UpdateResoGain(rCOEFF_GAIN *eff, REAL order, REAL we, REAL Ts);
void ResetResoGain(rCOEFF *eff);
void ExcuteReso(rCOEFF *eff, rCOEFF_GAIN *gain, REAL in);

#endif
