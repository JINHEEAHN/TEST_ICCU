
#ifndef USERINCLUDES_SOL_DEF_H_
#define USERINCLUDES_SOL_DEF_H_

#define FALSE					0
#define TRUE					1

#define BIT_OFF					0
#define BIT_ON					1

#define LOW						0
#define HIGH					1

#define INACTIVE				0
#define ACTIVE					1


#define		PI              	(3.141592654)
#define		PI2					6.283185307		/* 2*PI */
#define		INV_PI          	(0.318309886)
#define		SQRT2				(1.414213562)
#define		SQRT3           	(1.732050808)
#define		INV_SQRT2			(0.707106781)
#define		INV_SQRT3       	(0.577350269)
#define		SQRT2_INV_SQRT3 	SQRT2 * INV_SQRT3

#define abs(a)          (double)(((double)(a)<0) ? -(double)(a):(double)(a))


typedef unsigned				BOOL;
typedef unsigned char			BYTE;
typedef int						SWORD;
typedef unsigned int			WORD;
typedef long					SLONG;
typedef unsigned long			LONG;
typedef float					REAL;
typedef unsigned char			u8;
typedef BYTE					*pBYTE;
typedef WORD					*pWORD;
#define PWORD(x)				(*(unsigned volatile int *)(x))

#endif /* DEF_H_ */
