
#ifndef USERINCLUDES_BASE_H_
#define USERINCLUDES_BASE_H_

#include "F28x_Project.h"
#include "device.h"
#include "driverlib.h"
#include "f2838x_device.h"
#include <stdio.h>
#include <string.h>
#include "math.h"
#include "sw_interrupt_prioritization_logic.h"
#include "FlashAPI/F021_F2838x_C28x.h"
#include "FlashAPI/F021.h"
#include "easy28x_DriverLib_v11.2.h"
#include "sol_adc.h"
#include "sol_cmpss.h"
#include "sol_ControlFunction.h"
#include "sol_ControlMain.h"
#include "sol_dac.h"
#include "sol_def.h"
#include "sol_gpio.h"
#include "sol_pwm.h"
#include "sol_Reso.h"
#include "sol_spi.h"
#include "sol_timer.h"
#include "sol_util.h"
#include "sol_vari.h"


// ePWM Operation mode setting
#define __CLOSEDLOOP_MODE 1
//#define __OPENLOOP_MODE 1

// ePWM phase mode setting
#define __2ph_mode 1
//#define __3ph_mode 1

// operation mode(2ph)
#define __G2V_mode 1
//#define __V2L_mode 1
//#define __V2G_mode 1

// EVM ADC, PWM TEST
//#define __EVM_ADC_TEST 1



#define VER_YEAR        2025
#define VER_MONTH       5
#define VER_DAY         29
#define VER_NUM1        'D'     //(R(0x52) : ���, D(0x44) : �̾��)
#define VER_NUM2         0
#define VER_NUM3         0
#define VER_NUM4         1

#define FV_YEAR1    (VER_YEAR / 1000) + 0x30
#define FV_YEAR2    ((VER_YEAR % 1000) / 100) + 0x30
#define FV_YEAR3    ((VER_YEAR % 100) / 10) + 0x30
#define FV_YEAR4    (VER_YEAR % 10)  + 0x30

#define FV_MONTH1   (VER_MONTH / 10) + 0x30
#define FV_MONTH2   (VER_MONTH % 10) + 0x30

#define FV_DAY1     (VER_DAY / 10) + 0x30
#define FV_DAY2     (VER_DAY % 10) + 0x30

#define FV_NUM1     VER_NUM1
#define FV_NUM2     VER_NUM2 + 0x30
#define FV_NUM3     VER_NUM3 + 0x30
#define FV_NUM4     VER_NUM4 + 0x30

#endif /* USERINCLUDE_BASE_H_ */
