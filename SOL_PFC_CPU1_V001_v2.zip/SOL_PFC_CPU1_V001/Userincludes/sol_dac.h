
#ifndef USERINCLUDES_SOL_DAC_H_
#define USERINCLUDES_SOL_DAC_H_

extern	void DacInit(void);
extern	void InitDAC(void);
extern	void DAC_OUT(void);


#endif /* SOURCE_USER_HEADER_DAC_H_ */
