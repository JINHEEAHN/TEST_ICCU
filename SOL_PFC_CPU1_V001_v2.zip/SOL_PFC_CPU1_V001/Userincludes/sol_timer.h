
#ifndef USERINCLUDES_SOL_TIMER_H_
#define USERINCLUDES_SOL_TIMER_H_

extern Uint32 TIMER0_us(Uint32 us);
extern void Timer0_init(void);

extern WORD SwtIsr1msCnt;

#endif /* TIMER_H_ */
