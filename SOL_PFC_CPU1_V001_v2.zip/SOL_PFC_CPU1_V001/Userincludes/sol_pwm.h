
#ifndef USERINCLUDES_SOL_PWM_H_
#define USERINCLUDES_SOL_PWM_H_

//main.c
extern void Pwm_Init(void);
//sol_pwm.c
void F2838x_PWM_Init(void);
void EVM_ADC_PWM_TEST_Init(void); // EVM TEST Function

extern WORD wPeriod;

// Deadtime setting
#define		DBT_2USEC		 400
#define		DBT_0_5USEC		 100
#define     DBT_300NSEC      60
#define		DBT_150NSEC		 30
#define		DBT_100NSEC		 20
#define		DBT_110NSEC		 22
#define		DBT_120NSEC		 24
#define		DBT_130NSEC		 26
#define		DBT_80NSEC		 16
#define		DBT_70NSEC		 14
#define		DBT_0SEC		 0

// __EVM_ADC_TEST �׽�Ʈ�� variables(�Ʒ� 4��)
#define SYSCLK          200E6   // 200MHz, 28X Core(CPU)�� ���� Ŭ�� ���ļ�
#define TBCLK           10E6    // 10MHz, EPWM ��� 16��Ʈ Ÿ�̸Ӱ� ����ϴ� Ŭ�� ���ļ�
#define BUFF_SIZE       256     // ADC ��� ����� ���� ������
#define SAMPLING_FREQ   20E3    // 20kHz, ADC ���ø� ���ļ�


/* Define the system frequency (Hz) */
#define SYSCLKOUT				200000000

#define HISPCP_DIV_FACTOR		(1) 							// HSPCLOCK = SYSCLKOUT / HISPCP_DIV_FACTOR
#define LOSPCP_DIV_FACTOR		(4)								// default value, HISP clock prescaler

#define HISPCLOCK_PS			(HISPCP_DIV_FACTOR/2)			// HISP clock prescaler
#define LOSPCLOCK_PS			(LOSPCP_DIV_FACTOR/2)			// LOSP clock prescaler

#define HSPCLOCK				(SYSCLKOUT/HISPCP_DIV_FACTOR)	// default value
#define LSPCLOCK				(SYSCLKOUT/LOSPCP_DIV_FACTOR)	// default value

#define CLKGDV_VAL           1
#define MCBSP_INIT_DELAY  	 2 * (SYSCLKOUT/LSPCLOCK)                  // # of CPU cycles in 2 SRG cycles-init delay
#define MCBSP_CLKG_DELAY     2 * (SYSCLKOUT/(LSPCLOCK/(1+CLKGDV_VAL))) // # of CPU cycles in 2 CLKG cycles-init delay

#define TIMER_DIV_FACTOR_X_1  	(0)
#define TIMER_DIV_FACTOR_X_2  	(1)
#define TIMER_DIV_FACTOR_X_4  	(2)
#define TIMER_DIV_FACTOR_X_8  	(3)
#define TIMER_DIV_FACTOR_X_16 	(4)
#define TIMER_DIV_FACTOR_X_32 	(5)
#define TIMER_DIV_FACTOR_X_64 	(6)
#define TIMER_DIV_FACTOR_X_128	(7)

#define TIMER1_DIV_FACTOR			(TIMER_DIV_FACTOR_X_1)
#define TIMER2_DIV_FACTOR			(TIMER_DIV_FACTOR_X_1)
#define TIMER3_DIV_FACTOR			(TIMER_DIV_FACTOR_X_1)
#define TIMER4_DIV_FACTOR			(TIMER_DIV_FACTOR_X_8)

#define TIMER1_CLK_PRESCALE  	(0x0100 * TIMER1_DIV_FACTOR)	// Ÿ�̸��� prescaler ����
#define TIMER2_CLK_PRESCALE  	(0x0100 * TIMER2_DIV_FACTOR)	// Ÿ�̸��� prescaler ����
#define TIMER3_CLK_PRESCALE  	(0x0100 * TIMER3_DIV_FACTOR)	// Ÿ�̸��� prescaler ����
#define TIMER4_CLK_PRESCALE  	(0x0100 * TIMER4_DIV_FACTOR)	// Ÿ�̸��� prescaler ����

#define T1CLOCK		(HSPCLOCK / (0x0001 << TIMER1_DIV_FACTOR))
#define T3CLOCK		(HSPCLOCK / (0x0001 << TIMER3_DIV_FACTOR))
#define T4CLOCK		(HSPCLOCK / (0x0001 << TIMER4_DIV_FACTOR))

#define ENC_T_CLK	T4CLOCK				// ���ڴ� �ð����� Ÿ�̸��� Ŭ�� ���ļ�
#define DEFAULT_CARRIER	30000			// Define the switching frequency (KHz)
#define SWT_PERIOD		1e-3			// 1 msec, but, SWT_1MS_ISR period = 1 msec (interrupt on timer period & compare match)

// T1 = (4500), clock = 200MHz/2, period = 100usec = 4500 / (90MHz/2), 5kHz
//180624 JW #define	T1PRD		((unsigned int)(T1CLOCK/(DEFAULT_CARRIER)/2))
#define	T1PRD		((unsigned int)(T1CLOCK/(DEFAULT_CARRIER))/2)
#define	PWM_IO_PRD	((unsigned int)(T1CLOCK/(1000)))

#define	T2PRD		0xFFFF

// T3 Freq(Hz) = (150MHz/2)/4096=18.311kHz, T3PRD = (T3CLOCK/PWMDAC_CARRIER - 1)
#define	T3PRD_VAL	(4096)
#define	T3PRD		(T3PRD_VAL-1)

// T4PRD = (18750-1)
#define	T4PRD_VAL	((unsigned int)(T4CLOCK*SWT_PERIOD))
#define	T4PRD		(T4PRD_VAL - 1)

#define	FACTOR		325.7901685		/* 2047 / 6.28 */

#define	PWM_BUFFER_ENB		GpioDataRegs.GPCCLEAR.bit.GPIO91 = 1
#define	PWM_BUFFER_DIS		GpioDataRegs.GPCSET.bit.GPIO91 = 1

#define	PWM_ENB														\
						EPwm6Regs.AQCSFRC.bit.CSFA = 0;				\
						EPwm6Regs.AQCSFRC.bit.CSFB = 0;				\
						EPwm7Regs.AQCSFRC.bit.CSFA = 0;				\
						EPwm7Regs.AQCSFRC.bit.CSFB = 0;				\
						EPwm8Regs.AQCSFRC.bit.CSFA = 0;				\
						EPwm8Regs.AQCSFRC.bit.CSFB = 0;				\
                        EPwm9Regs.AQCSFRC.bit.CSFA = 0;             \
                        EPwm9Regs.AQCSFRC.bit.CSFB = 0;             \
						PWM_BUFFER_ENB;
						//LED4_ON;

#define	PWM_BLK														\
						EPwm6Regs.AQCSFRC.bit.CSFA = 1;				\
						EPwm6Regs.AQCSFRC.bit.CSFB = 1;				\
						EPwm7Regs.AQCSFRC.bit.CSFA = 1;				\
						EPwm7Regs.AQCSFRC.bit.CSFB = 1;				\
						EPwm8Regs.AQCSFRC.bit.CSFA = 1;				\
						EPwm8Regs.AQCSFRC.bit.CSFB = 1;				\
                        EPwm9Regs.AQCSFRC.bit.CSFA = 1;             \
                        EPwm9Regs.AQCSFRC.bit.CSFB = 1;             \
						PWM_BUFFER_DIS;
						//LED4_OFF;

#define Trip_CLR													\
						EALLOW;										\
						EPwm6Regs.TZCLR.bit.OST = 1;				\
						EPwm6Regs.TZCLR.bit.DCAEVT1 = 1;			\
						EPwm7Regs.TZCLR.bit.OST = 1;				\
						EPwm7Regs.TZCLR.bit.DCAEVT1 = 1;			\
						EPwm8Regs.TZCLR.bit.OST = 1;				\
						EPwm6Regs.TZCLR.bit.INT = 1;				\
						EPwm7Regs.TZCLR.bit.INT = 1;				\
						EPwm8Regs.TZCLR.bit.INT = 1;				\
						EDIS;										\

extern WORD ControlMode;

enum {
	FLT_SW_OC_Iac,					//0		0x   00001
	FLT_SW_OC_Iboost,				//1		0x   00002
	FLT_SW_OC_GRID,					//2		0x   00004
	FLT_ASHT,						//3  	0x   00008
	FLT_SW_OV_SOLAR, 				//4		0x   00010
	FLT_SW_OV_BOOST,      			//5		0x   00020
	FLT_SW_OV_BUCK,    				//6		0x   00040
	FLT_SW_OV_GRID,					//7  	0x   00080
	FLT_SW_LV_SOLAR,         		//8		0x   00100
	FLT_SW_LV_BOOST,       			//9		0x   00200
	FLT_SW_LV_RMS_GRID,	     		//10	0x   00400
	FLT_SW_OV_RMS_GRID,				//11 	0x   00800
	FLT_SW_OC_RMS_GRID,				//12	0x   01000
	FLT_ADC_OFFSET,					//13	0x   02000
	FLT_OHT_HS_SENSOR,				//14	0x   04000
	FLT_OHT_PCB_SENSOR,				//15 	0x   08000
	FLT_LOST_GRID_FREQ,				//16	0x   10000
	FLT_INIT_CHARGE_FAIL,			//17	0x   20000
	FLT_RELAY_FAULT, 				//18	0x   40000
	FLT_LOST_COMMAND,				//19    0x   80000
	FLT_HW_OC_BUCK,					//20	0x  100000
	FLT_HW_OC_BOOST,				//21	0x  200000
	FLT_HW_OC_GRID,					//22	0x  400000
	FLT_HW_FLT,					//23	0x  800000
	FLT_RESERVE7,					//24	0x 1000000
	FLT_RESERVE6,					//25	0x 2000000
	FLT_RESERVE5,					//26	0x 4000000
	FLT_RESERVE4,					//27	0x 8000000
	FLT_RESERVE3, 					//28	0x10000000
	FLT_RESERVE2, 					//29	0x20000000
	FLT_RESERVE1, 					//30	0x40000000
	FLT_RESERVE0					//31	0x80000000
};

#endif

