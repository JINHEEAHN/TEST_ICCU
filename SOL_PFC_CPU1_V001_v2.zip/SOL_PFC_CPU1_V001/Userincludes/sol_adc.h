
#ifndef USERINCLUDES_SOL_ADC_H_
#define USERINCLUDES_SOL_ADC_H_

//#define ADC_ISR

extern void Init_adcA(void);
extern void Init_adcB(void);
extern void Init_adcC(void);
extern void Init_adcD(void);
extern void AdcInit(void);
extern	void AdcOffsetCal(void);
extern	void ReadAD(void);
__interrupt void ISR_ADCA(void);
__interrupt void ISR_ADCB(void);
__interrupt void ISR_ADCC(void);
__interrupt void ISR_ADCD(void);
#define	ADC_OFFSET_SHIFT	12
#define ADC_HALF			2048

#endif /* ADC_H_ */
