#include "base.h"

int OPER_MODE = 0;
int Start = 0;
int theta_count=0;
double CT_gain = 1.6129;
double CT_gain1 = 81; //78;
double CT_gain2 = 81; //78;
double CT_gain3 = 81; //78;
double CT_op_gain1 = 1.0989;
double CT_op_gain2 = 1.098;
double CT_op_gain3 = 1.333;
double CT_offset = 2.486;
double CT_offset1 = 2.275; //2.475; //2.49; //2.478;
double CT_offset2 = 2.49; //2.49; //2.501;
double CT_offset3 = 2.495; //2.49; //2.501;
double V_AC_gain = 1.01;
double V_AC_gain1 = 1.43; //1.50; //1.36; //1.50; //1.38; //1.01;
double V_AC_gain2 = 1.42; //1.50; //1.382; //1.01;
double V_AC_gain3 = 1.36; //1.42; //1.381; //1.01;
double V_AC_peak = 311;
double V_AC_offset = 1.835;
double V_AC_offset1 = 1.84; //1.862; //1.94; //1.86; //1.9;   //1.83; //1.835;
double V_AC_offset2 = 1.618000031; //1.85;  //1.84; //1.835;
double V_AC_offset3 = 1.84; //1.825; //1.85; //1.835;
double V_AC_gain_link = 0.4449999928;
double HCPL_gain = 0.12;
double HCPL_gain1 = 0.12;
double HCPL_gain2 = 0.12;
double HCPL_gain3 = 0.12;
double I_PFC_FB;
double I_PFC_FB_input;
double I_PFC_A;
double I_PFC_B;
double I_PFC_A_input;
double I_PFC_B_input;
double I_PFC_C_input;
double I_PFC_C;
double V_AC_A;
double V_AC_FB;
double V_AC_FB;
double V_AC_FB;
double V_AC;
double VAC_abs;
int MC_on;
double DC_link_V_G = 0.272; //0.265; //0.2625;
double DC_link_V;
double T_timer=0;
double DC_link_V_input;
int SW_trip=0;
double LPF_gain2=0.3;
double LPF_gain3=0.5;
double  PI_pfc_I_B_out_new=0;
double  PI_pfc_I_A_out_new=0;

double LPF_w=0, V_AC_FB_old=0, Vqs_LPF=0;

double PLL_Pterm =0, PLL_Iterm =0, PLL_omega=0;
double Kp_PLL=5, Ki_PLL = 38;

// Burst variables
unsigned int Burst_Mode;
unsigned int BM_Pwm_Block;
unsigned int Flag_BM_Hi_Limit;
unsigned int Flag_BM_Lo_Limit;
double SET_BURST_HI_LEVEL, SET_BURST_LO_LEVEL, SET_BURST_DEL_VOLT;

// IIR Filter variables
float adc_samples_I[NUM_SAMPLES] = {0,};
int avg_index_I;
float adc_samples_V[NUM_SAMPLES] = {0,};
int avg_index_V;
float Avg_cal_V;
float Avg_cal_I;

////////////////////Revised by SD 21.09.14////////////////////////////////
int PFC_cnt=0;
double PI_pfc_I_V;
double PI_pfc_P_V;
double PI_pfc_V_out;
double PI_pfc_I_i_A;
double V_DC_ref=600;
double PI_pfc_P_i_A;
double PI_pfc_I_A_out;
double PI_pfc_I_i_B;
double PI_pfc_P_i_B;
double PI_pfc_I_B_out;

double KI_pfc_V=10; //1;
double KP_pfc_V=0.01; //0.05;
double KI_pfc_i=20000; //10000; //10000;
double KP_pfc_i=20; //50; //50;
int PFC_Flag=0;
int I_control = 0;

int single_phase_mode = 0;
int Precharge = 0;
int MC_on = 0;
int MC_off = 0;
////////////////////////////////////////////////////////////////////////////////////
/////////////////////Protection Revised by SD 2021.09.27//////////////////////////////////////
int Iin_cnt = 0;
int Trip_enable=1;
int trip_cnt=0;
int trip_ready=0;
int trip_Iin_cnt = 5;

int Vout_cnt=0;
int trip_Vout_cnt = 5;

double delt_Vout=1;
double V_DC_ref_ss=300;
int ss_cnt=0;

double I_i_A_ref, I_i_A_err, I_i_B_ref, I_i_B_err;
//////////////////////Revised by SD 2021.09.09/////////////////////////////////////
// PLL setting
double ff_theta =0;
int theta_run =0;

double VAC_freq = 60;

double We_S_angle_I=0;
double We_S_angle_P=0;

double V_RT =0.0;
double V_ds_S_angle =0.0;
double phase_angle_rad =0.0;

double phase_angle =86.0;
double cutoff_freq =0.0;
double cut_Vin = 600.0;
double LPF_gain = 0.6;
double LPF_gain_Vout = 0.8;
double LPF_gain_IinA = 0.1;
double I_i_A_ref_in = 0;
double I_i_B_ref_in = 0;
double LPF_gain_I = 0.5; //0.8;

double V2L_sin = 0.0;

double A_inv =0.0;
double C_TSAMP =0.0001;
double B_inv =0.0;
double V_qs_S_angle =0.0;
double V_ds_S_angle_old =0.0;
double V_qs_S_angle_old =0.0;
double Vds_S_angle =0.0;
double Vqs_S_angle =0.0;
double Vde_S_angleFlt =0.0;
double Kf1_S =0.940882602;
double Vde_S_angle0 =0.0;
double Kf2_S =0.059117397;
double Vde_S_angle =0.0;
double Vde_S_angleErr =0.0;

double Vde_S_angleRef =0.0;

int limit_cnt=0;
double We_S_angle =0.0;
double We_S_angleOld =0.0;
//double KpTheta_S =0.1;
//double KiTheta_S =108.5;
//double Theta =0.0;
//double Theta2 = 0.0;
double KpTheta_S =0.5;
double KiTheta_S =100;
//double Kf2_S =0.1;

double Vde_S_angleErr0 =0.0;
double Vqe_S_angle =0.0;

//////////////////////////////V2G ���� ����

float k_w = 0;
float L_w = 0;
float Vds = 0;
float Vqs = 0;
float fsw = 40000;
float fg = 60;
float past_Vds = 0;
float past_Vqs = 0;
float Vde = 0;
float Vqe = 0;
float rtheta = 0;

float rVerr = 0;
float V_Pterm = 0;
float V_Iterm = 0;
float V_PIterm = 0;
float rKp_V = 0.5;
float rKi_V = 20;
float rIL_ref = 0;
float rVref = 311;

float rIL1_err = 0;
float IL1_Pterm = 0;
float IL1_Iterm = 0;
float IL1_PIterm = 0;
float rIL2_err = 0;
float IL2_Pterm = 0;
float IL2_Iterm = 0;
float IL2_PIterm = 0;
float rKp_IL = 2;
float rKi_IL = 100;

float IL14=0;
float IL13=0;
float IL12=0;
float IL11=0;
float IL24=0;
float IL23=0;
float IL22=0;
float IL21=0;

float Po = 11;
float Vac_rms = 220;

int Flag1 = 0;
int Flag2 = 0;
int Flag1_1 = 0;
int Flag2_1 = 0;


float Theta_V2L = 0;

int TB_inveterPRD = 1111;
int PWM_PRD_half_INV = 556;
float		PWM_Ts = 0.000022;

unsigned int	wCntAdca = 0;
unsigned int	wCntAdcb = 0;
unsigned int	wCntAdcc = 0;
unsigned int    wCntAdcd = 0;

unsigned int	wMainCnt = 0;

unsigned int	SPI_BUFF_DATA_0=0;
unsigned int	SPI_BUFF_DATA_1=0;
unsigned int	SPI_BUFF_DATA_2=0;
unsigned int	SPI_BUFF_DATA_3=0;

long	VDC_IN_AD_Integ;
long	VDC_BOOST_AD_Integ;
long	CURR_BOOST_AD_Integ;
long	VIN_AC_AD_Integ;
long	CURR_AC_AD_Integ;
long    CURR_AC_AD_Integ_SJ;


long Test_ADCA2_Integ;
long Test_ADCA3_Integ;
long Test_ADCA4_Integ;
long Test_ADCA5_Integ;

long Test_ADCB2_Integ;
long Test_ADCB3_Integ;




unsigned int 	SET_DAC_DATA0, SET_DAC_DATA1, SET_DAC_DATA2, SET_DAC_DATA3;
unsigned int 	SET_DAC_OFFSET0, SET_DAC_OFFSET1, SET_DAC_OFFSET2, SET_DAC_OFFSET3;
unsigned int 	SET_DATA_TYPE0, SET_DATA_TYPE1, SET_DATA_TYPE2, SET_DATA_TYPE3;
float 	SET_DAC_SCALE0, SET_DAC_SCALE1, SET_DAC_SCALE2, SET_DAC_SCALE3;
float	SET_VOLT_SCALE0, SET_VOLT_SCALE1, SET_VOLT_SCALE2, SET_VOLT_SCALE3;

unsigned int	wVDC_IN_AD;
unsigned int	wVDC_BOOST_AD;
unsigned int	wCURR_BOOST_AD;
unsigned int	wVIN_AC_AD;
unsigned int	wCURR_AC_AD;

unsigned int wTest_ADCA2;
unsigned int wTest_ADCA3;
unsigned int wTest_ADCA4;
unsigned int wTest_ADCA5;
unsigned int wTest_ADCB2;
unsigned int wTest_ADCB3;
unsigned int wTest_ADCB4;


float	wVDC_IN_AD_LPF;
float	wVDC_IN_AD_oldLPF;
float	ALPHA_wVDC_IN;

float	wVDC_IN_AD_LPF_Low;
float	wVDC_IN_AD_oldLPF_Low;
float	ALPHA_wVDC_IN_Low;

float	wVDC_BOOST_AD_LPF;

float	wVDC_BOOST_AD_oldLPF;
float	ALPHA_wVDC_BOOST;

float   wCURR_BOOST_AD_LPF;

float	wCURR_BOOST_AD_oldLPF;
float	ALPHA_wCURR_BOOST;

float	wVIN_AC_AD_LPF;

float	wVIN_AC_AD_oldLPF;
float	ALPHA_wVIN_AC;

float	wCURR_AC_AD_LPF;
float	wCURR_AC_AD_oldLPF;
float	ALPHA_wCURR_AC;

float	rVDC_INLPF,	rVDC_BOOSTLPF, rCURR_BOOSTLPF, rVIN_ACLPF, rCURR_ACLPF, rVDC_INLPF_L;

float	rVDC_IN, rVDC_BOOST, rCURR_BOOST, rVIN_AC, rCURR_AC;
float	rVDC_IN_SenScale, rVDC_BOOST_SenScale, rCURR_BOOST_SenScale, rVIN_AC_SenScale, rCURR_AC_SenScale;

float rTest_ADCA2_SenScale = 1.0;
float rTest_ADCA3_SenScale = 1.0;
float rTest_ADCA4_SenScale = 1.0;
float rTest_ADCA5_SenScale = 1.0;

float rTest_ADCB2_SenScale = 1.0;
float rTest_ADCB3_SenScale = 1.0;

float rTest_ADCA2, rTest_ADCA3, rTest_ADCA4, rTest_ADCA5, rTest_ADCB2, rTest_ADCB3;

float	rCURR_AC_FLT;
int	VDC_IN_AD_Offset,VDC_BOOST_AD_Offset,CURR_BOOST_AD_Offset,VIN_AC_AD_Offset,CURR_AC_AD_Offset;

int Test_ADCA2_Offset, Test_ADCA3_Offset,Test_ADCA4_Offset,Test_ADCA5_Offset,Test_ADCB2_Offset,Test_ADCB3_Offset;

float	rFltFreqVdcBoost;
float	rFltFreqVdcIN;
float	rFltFreqCurrBoost;
float	rFltFreqCurrAC;
float	rFltFreqVAC1;
float	rFlt_LowFreqVdcIN;

float	TsCla = 0.00002;	//50khz Sampling 1/50000

float	rIdss;
float	rIqss;
float	rIdse;
float	rIqse;
float	rIdseRef = 0;
float	rIqseRef = 0;
float	rErrIdse;
float	rErrIqse;
float	rVdseAnti = 0;
float	rVqseAnti = 0;
float	rIdseRefOut = 0;
float	rIqseRefOut = 0;
float	rIdseErrPterm;
float	rIqseErrPterm;
float	rIdseErrIterm = 0;
float	rIqseErrIterm = 0;
float	rVRef;
float	rCurKpd;
float	rCurKid;
float	rCurKad;
float	rCurKpq;
float	rCurKiq;
float	rCurKaq;
float	rCurAlpha = 0;
float	rDirIdse = -1;
float	rDirIqse = -1;
float	rVdseRefDeCop = 0;
float	rVqseRefDeCop = 0;
float	rVseRefMin = 0,	rVseRefMax = 0;
float	VdseRefFeedFoward = 0;
float	VqseRefFeedFoward = 0;
float	rVdseRefHighLimit, rVdseRefLowLimit;
float	rVqseRefHighLimit, rVqseRefLowLimit;

float	rVqseLPF, rVdseLPF, VqseOldLpf, VdseOldLpf;
float	ALPHA_LPF_Vqse;
float	ALPHA_LPF_Vdse;
float	ALPHA_SHT;
float	rVqssOldSht;
float	rVdssOldSht;
float	rIqssOldSht;
float	rIdssOldSht;

float	rKiPll,	rKpPll, Theta, Theta2, rPhase_delay_DEG2, VqseOldPLL, WeGrid;
double	rSIN, rSIN2, rCOS, rCOS2;
float	ThetaOffset = -1.5;

unsigned long	lFaultStatus = 0x00000000;
unsigned int	wBoundOC = 0;
unsigned int	wFltCountIac = 0;
unsigned int	wFltCountIboost = 0;
unsigned int	wFltCountVac = 0;

float	SET_OCT_BOOST_LEVEL, SET_OCT_AC_LEVEL, SET_OVT_VDCIN_LEVEL, SET_OVT_BOOST_LEVEL, SET_OVT_AC_LEVEL;

unsigned int	TestDuty= 0;
unsigned int 	TestDuty_2=0 ;
unsigned int 	ControlMode = 0;
unsigned int 	wPwmIsrCnt = 0;
unsigned int 	pwmcnt=0;
unsigned int 	t_on_1st =0;
unsigned int 	t_on_2nd =0;
unsigned int 	dt_on = 50;
unsigned int	dt_off =50;

unsigned int RED_TEST= 20;
unsigned int FED_TEST= 20;
unsigned int set3=2;
unsigned int set2=2;
unsigned int set1=1;
unsigned int out_mode_TEST=0;
unsigned int in_mode_TEST=0;
unsigned int polsel_test=0;
unsigned int reference_=0;
unsigned int kjw=0;
float reference_Freq=0;
unsigned int Theta_offset=667;
unsigned int wCntTripZone6 = 0;
unsigned int wCntTripZone7 = 0;
unsigned int wCntTripZone8 = 0;

unsigned int FLT_BOOST = 0;
unsigned int FLT_INT_OCDINT = 0;
unsigned int FLT_INT_OCDENT = 0;
unsigned int FLT_INV = 0;
unsigned int RLY_STATE = 0;
float Ma=0;
float Mf=0;
float Theta_=0;
float Vref = 0;
float _Vref = 0;
unsigned int RLY_CTRL = 0;
unsigned int FaultReset = 0;
unsigned int PWM_INV_SYNC = 1;
float rVboostDuty = 0;
float rBoostDuty = 0;
float DELTA_THETA = 0;

float	rRamp_step = 0;
float	rNowValue = 0;
float	V_ref = 0;
float	time = 0.1;
float	P_Duty = 0;
float	P_Ref = 0;

float	rErr_VBoost = 0;
float	rPterm_VBoost = 0;
float	rKp_VBoost = 0;
float	rIterm_VBoost = 0;
float	rKi_VBoost = 0;
float	rRef_VBoost = 0;

float	rErr_IBoost = 0;
float	rPterm_IBoost = 0;
float	rKp_IBoost = 0;
float	rIterm_IBoost = 0;
float	rKi_IBoost = 0;
float	rRef_IBoost = 0;
unsigned int PI_Control_Cnt = 0;
float ALPHA_Vref_half, Vref_half_old, rFLTFreqVref, Vref_half;

float Vac_in_old, Vac_out_old, rV_alpha, rV_beta, rVd_Conv, rVq_Conv;
float rErrVq_Conv, rKpVq, rKiVq, Vq_ConvPterm, Vq_Conviterm, rRef_VqConv, rVIN_AC_phase;

float rVIN_AC_outold, rVDC_outold, rVDC_BOOST_outold, rCURR_BOOST_outold;

float CutOffFreq_APF;
float CutOffFreq_AD;
float Vref_half_in_old = 0;
float Vref_half_out_old = 0;
float sampleFreq;
float Ws = 377;
float rVq_Ref = 0;
float rSin =0;
float rCos =0;

float rCURR_AC_phase, Iac_in_old, Iac_out_old;
float rIds, rErrIds, rIdsPterm, rKpdsGain, rIdsIterm, rKidsGain, rRef_Ids_Curr, rId_Conv, rId_alpha, rId_alpha_Phase;
float rIqs, rErrIqs, rIqsPterm, rKpqsGain, rIqsIterm, rKiqsGain, rRef_Iqs_Curr, rIq_Conv, rIq_beta;

float rRef_Ids = 0;
float rRef_Iqs = 0;

float rCURR_AC_outold, rCURR_AC_inold;
float rId_Conv_outold, rId_Conv_inold, rIq_Conv_outold, rIq_Conv_inold, rId_Conv_LPF, rIq_Conv_LPF;
float rPWM6_Ref, rPWM7_Ref, rPwmScaleFactor;
unsigned int Mode_Select = 0;
float rErrVqse, rIq_alpha,  rVdse, rVdss, rVKiPLL, rVKpPLL, rVqse, rVqseErrIterm, rVqseErrPterm, rVqseRef, rVqss, rVqseRefOut;
unsigned int Inverter_Start = 0;

float	rVdss_LPF, rVqss_LPF, rVdss_outold, rVqss_outold;
float	rIdss_LPF, rIqss_LPF, rIdss_outold, rIqss_outold;

float	rVdse_LPF, rVdse_outold, VdseCutoff;

float	rVdcScaleLPF, rVdcScale_old;

float bHarComp3, bHarComp5, bHarComp7, bHarComp9, bHarComp11, bHarComp13;

float	rControlTime = 0.0001;
float	rWeGridLPF = 377;
float	HAR_LIMIT = 25;

unsigned int Controlflag = 0;
int Test_TBPRD=999; //50kHz
int Start_Flag=0;
unsigned int ReadADcnt=0;

//////theta ���� ����
unsigned int theta_run_r = 0;

//////3ph PWM ���� ����
double Pwm0_ENn = 0;
int short_circuit = 0;
int cnt_PWM = 0, flag1 = 0, flag2 = 0;

double theta_start = 0;
double V_UV = 0;
double V_WU = 0;
double V_VW = 0;
double theta_th = 0;
double theta_de = 0;
double Ki_Vqe = 100;
double Kp_Vqe = 10;
double V_U, V_V, V_W;
double PLL_Error = 0;
double Iq_th, Pq_th, Vds_th, Vde_th, Vqe_th, Vqs_th, w_th;

double control_start = 0;
double I_U = 0;
double I_V = 0;
double I_W = 0;
double Ids_th, Iqs_th, Ide_th, Iqe_th;
int ss_cnt_th = 0;
int V_count = 0;
double Verror_th = 0;
double Kp_vol = 0.1;      //��������� P gain
double KI_vol = 2;      //��������� I gain
double P_vol, I_vol, PI_vol;

double Iref_d = 0;
double Ierror_d = 0;
double Kp_cur_d = 2;    //��������� P gain : d��
double KI_cur_d = 100;  //��������� I gain : d��
double I_cur_d = 0;
double P_cur_d = 0;
double PI_cur_d = 0;
double PI_cur_d_F = 0;

double Iref_q = 0;
double Ierror_q = 0;
double Kp_cur_q = 5;    //��������� P gain : q��
double KI_cur_q = 120;  //��������� I gain : q��
double I_cur_q = 0;
double P_cur_q = 0;
double PI_cur_q = 0;
double PI_cur_q_F = 0;
double Vdeff = 0;

double Ids_F = 0;
double Iqs_F = 0;
double IU_ref = 0;
double IV_ref = 0;
double IW_ref = 0;
double Min = 0;
double Max = 0;
double VU_ref = 0;
double VV_ref = 0;
double VW_ref = 0;
double Vmm = 0;

//flag
Uint16 wtest_flag;
