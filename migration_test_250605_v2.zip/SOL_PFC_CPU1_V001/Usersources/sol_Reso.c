
#include "F28x_Project.h"
#include "base.h"
#include "sol_Reso.h"

void InitResoVariable(rCOEFF * eff)
{
	eff->Wh = 0;				
	eff->Kr = 1;				
	eff->Cr1 = 0;			  
	eff->Cr2 = 0;			  
	eff->Cr3 = 0;			  
	eff->Kt1 = 0;			  
	eff->Kt2 = 0;			  
	eff->delayComp = 2;; 
	eff->Zt = 0;				
	eff->Pt = 0;				
	eff->Kc = 0;				
	eff->K1 = 0;				
	eff->K2 = 0;				
	eff->K3 = 0;				
	eff->Ref = 0;			  
	eff->RefOld = 0;		
	eff->Out = 0;			  
	eff->OutOld = 0;		
	eff->OutOld1 = 0;	  
	eff->OutOld2 = 0;	  
	eff->ErrOld1 = 0;	  
	eff->ErrOld2 = 0;	  
}

void UpdateResoGain(rCOEFF_GAIN *eff, REAL order, REAL we, REAL Ts)
{
	eff->Wh = order * we;
	eff->Cr1 = tan(eff->Wh * Ts * 0.5);
	eff->Cr2 = 1 - eff->Cr1 * eff->Cr1;
	eff->Cr3 = 1 + eff->Cr1 * eff->Cr1;
	
	eff->Kt1 = __divf32(__divf32(eff->Cr1, eff->Wh), eff->Cr3);
	eff->Kt2 = 2. * __divf32(eff->Cr2, eff->Cr3);
}

void ResetResoGain(rCOEFF *eff)
{
	eff->	Ref = 0;
	eff->	RefOld = 0;
	eff->	Out = 0;
	eff->	OutOld = 0;
	eff->	OutOld1 = 0;
	eff->	OutOld2 = 0;
	eff->	ErrOld1 = 0;
	eff->	ErrOld2 = 0;
}

void ExcuteReso(rCOEFF *eff, rCOEFF_GAIN *gain, REAL in)
{
	REAL	Err;

	Err = -eff->Kr * in;
	eff->Ref = gain->Kt1 * (Err - eff->ErrOld2);
	eff->Ref += gain->Kt2 * eff->OutOld1;
	eff->Ref -= eff->OutOld2;
	
	eff->ErrOld2 = eff->ErrOld1;
	eff->ErrOld1 = Err;
	eff->OutOld2 = eff->OutOld1;
	eff->OutOld1 = eff->Ref;
}

