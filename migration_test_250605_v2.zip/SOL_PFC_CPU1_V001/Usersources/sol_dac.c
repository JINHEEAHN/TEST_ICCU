//#include "F28x_Project.h"
#include "base.h"

WORD DAC_test=0;
float kjw2=0;

#pragma CODE_SECTION (DAC_OUT, ".TI.ramfunc" )

void DacInit(void)
{
	// DACA ��� �ʱ�ȭ
	EALLOW;
	DacaRegs.DACCTL.bit.DACREFSEL	= 1;		// 0 VDDA(+)/VSSA(-) are the reference voltages
//	DacaRegs.DACCTL.bit.SYNCSEL		= 3;		// DAC PWMSYNC Select ; n-1
	DacaRegs.DACCTL.bit.LOADMODE	= 0;		// 1 Load on next EPWMSYNCPER specified by SYNCSEL
	DacaRegs.DACOUTEN.bit.DACOUTEN  = 1;		// 1 DAC Output Enable
	DELAY_US(10);								// Delay for buffered DAC to power up
	EDIS;

	// DACB ��� �ʱ�ȭ
	EALLOW;
	DacbRegs.DACCTL.bit.DACREFSEL	= 1;		// 0 VDAC/VSSA are the reference voltages
//	DacbRegs.DACCTL.bit.SYNCSEL		= 3;		// DAC PWMSYNC Select ; n-1
	DacbRegs.DACCTL.bit.LOADMODE	= 0;		// 1 Load on next EPWMSYNCPER specified by SYNCSEL
	DacbRegs.DACOUTEN.bit.DACOUTEN  = 1;		// 1 DAC Output Enable
	DELAY_US(10);
	EDIS;

	// DACC ��� �ʱ�ȭ
	EALLOW;
	DaccRegs.DACCTL.bit.DACREFSEL	= 1;		// 0 VDAC/VSSA are the reference voltages
//	DaccRegs.DACCTL.bit.SYNCSEL		= 3;		// DAC PWMSYNC Select ; n-1
	DaccRegs.DACCTL.bit.LOADMODE	= 0;		// 1 Load on next EPWMSYNCPER specified by SYNCSEL
	DaccRegs.DACOUTEN.bit.DACOUTEN  = 1;		// 1 DAC Output Enable
	DELAY_US(10);
	EDIS;

	DacaRegs.DACVALS.bit.DACVALS = 0;			// DAC �ʱ� ��� ����
	DacbRegs.DACVALS.bit.DACVALS = 0;			// DAC �ʱ� ��� ����
	DaccRegs.DACVALS.bit.DACVALS = 0;			// DAC �ʱ� ��� ����
}

// main���� ����ϸ� �Ǵµ�, easyDSP���� ���� �����ؼ� �����. �ʿ� �� main.c�� ���
void InitDAC(void)
{
	SET_DAC_DATA0 = 0.;
	SET_DAC_SCALE0 = 1.;
	SET_VOLT_SCALE0 = 1.;
	SET_DAC_OFFSET0 = 2048;
	SET_DATA_TYPE0 = 1;

	SET_DAC_DATA1 = 0.;
	SET_DAC_SCALE1 = 1.;
	SET_VOLT_SCALE1 = 1.;
	SET_DAC_OFFSET1 = 2048;
	SET_DATA_TYPE1 = 1;

	SET_DAC_DATA2 = 0.;
	SET_DAC_SCALE2 = 1.;
	SET_VOLT_SCALE2 = 1.;
	SET_DAC_OFFSET2 = 2048;
	SET_DATA_TYPE2 = 1;

	SET_DAC_DATA3 = 0.;
	SET_DAC_SCALE3 = 1.;
	SET_VOLT_SCALE3 = 1.;
	SET_DAC_OFFSET3	 = 2048;
	SET_DATA_TYPE3 = 1;
}

void DAC_OUT(void)
{
	//28377 Internal DAC
	SET_DAC_SCALE0 = 204.8 / SET_VOLT_SCALE0;
	SET_DAC_SCALE1 = 204.8 / SET_VOLT_SCALE1;
	SET_DAC_SCALE2 = 204.8 / SET_VOLT_SCALE2;
//	SET_DAC_SCALE3 = 204.8 / SET_VOLT_SCALE3;
    DAC_test ++;

	switch(SET_DATA_TYPE0)
	{
		case 0 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((*(float *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0)& 0x0FFF);						break;
		case 1 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0)& 0x0FFF);			break;
		case 2 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA0) * SET_DAC_SCALE0)  + SET_DAC_OFFSET0)& 0x0FFF);		break;
	}
	DELAY_US(2);
	switch(SET_DATA_TYPE1)
	{
		case 0 :  DacbRegs.DACVALS.bit.DACVALS = ((unsigned int)(((*(float *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1)& 0x0FFF);						break;
		case 1 :  DacbRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1)& 0x0FFF);			break;
		case 2 :  DacbRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA1) * SET_DAC_SCALE1)  + SET_DAC_OFFSET1)& 0x0FFF);		break;
	}
	DELAY_US(2);
	switch(SET_DATA_TYPE2)


	{
		case 0 :  DaccRegs.DACVALS.bit.DACVALS = ((unsigned int)(((*(float *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2)& 0x0FFF);						break;
		case 1 :  DaccRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2)& 0x0FFF);			break;
		case 2 :  DaccRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA2) * SET_DAC_SCALE2)  + SET_DAC_OFFSET2)& 0x0FFF);		break;
	}
	DELAY_US(2);

	/*switch(SET_DATA_TYPE3)
	{
		case 0 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((*(float *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;						break;
		case 1 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned int *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;			break;
		case 2 :  DacaRegs.DACVALS.bit.DACVALS = ((unsigned int)(((float)(*(unsigned char *)SET_DAC_DATA3) * SET_DAC_SCALE3)  + SET_DAC_OFFSET3) & 0x0FFF) | 0xB000;		break;
	}*/
}

	//28377 ���� DAC ����ڵ�
	/*
	DacaRegs.DACVALS.bit.DACVALS = AdcaResultRegs.ADCRESULT2;
	DELAY_US(2);
	DacbRegs.DACVALS.bit.DACVALS = AdcbResultRegs.ADCRESULT0;
	DELAY_US(2);
	DaccRegs.DACVALS.bit.DACVALS = AdcbResultRegs.ADCRESULT2;
	*/
