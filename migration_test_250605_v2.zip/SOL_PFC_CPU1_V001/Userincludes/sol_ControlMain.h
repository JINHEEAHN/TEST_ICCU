
#ifndef USERINCLUDES_SOL_CONTROLMAIN_H_
#define USERINCLUDES_SOL_CONTROLMAIN_H_

enum { Ready, Ideal, Debuger, Inverter_Openloop, Boost_Openloop, Inverter_Closedloop, Boost_Closedloop, Boost_Inverter, STOP};
enum { Openloop = 1, Grid};

#define		  DQS_to_DQE(Vdss,Vqss,Vdse,Vqse,theta_DQ)										\
																							\
                  Vdse = Vdss*sin(theta_DQ) - Vqss*cos(theta_DQ);									\
                  Vqse = Vdss*cos(theta_DQ) + Vqss*sin(theta_DQ);

#define		PhaseShifer(out, in, out_old, in_old, alpha) {									\
						in_old += (in - in_old) * alpha;	\
						out_old += (in_old - out_old) * alpha;	\
						out = out_old * 2;															\
					}

#define LowpassFilter(Input, Output, SamplingFrequency, CutOffFrequency, PastInput, PastOutput) {	\
		float a1, b0, b1, w0;			\
		w0 = 2 * PI * CutOffFrequency;	\
		a1 = (w0 - 2 * SamplingFrequency) / (2 * SamplingFrequency + w0);	\
		b0 = w0 / (2 * SamplingFrequency + w0);	\
		b1 = b0;	\
		Output = b0 * (Input) + b1 * (PastInput) - a1 * (PastOutput);	\
		PastOutput = Output;	\
		PastInput = Input;	\
}

#define		PWM_PRD_Boost 1000
#define		PWM_PRD_INV	1333
//#define		PWM_PRD_half_INV	667
#define		ISR_f	37500

interrupt void PWM_ISR(void);
interrupt void EPwmIsr_openloop(void);
interrupt void EPwmIsr_test(void);

__interrupt void CPU_TIMER0_ISR(void);

void protection(void);
void PLL_Cal(void);
void closed_loop_Test(void);
__interrupt void ISR_TRIP_ZONE6(void);
__interrupt void ISR_TRIP_ZONE7(void);
__interrupt void ISR_TRIP_ZONE8(void);

void BoostCal(void);
void CMD_STOP(void);
void Curr_Cal(void);
void Fault_Clear(void);
void Openloop_Theta(void);
void OutputControl(void);
void openloop_Inverter(void);
void openloop_Boost(void);
void DebugerMode(void);
void BoostInverterCal(void);
void PRController(void);

float calculate_filtered_average(float *adc_samples, int num_samples);
void update_adc_samples(float *adc_avg, float new_value, int *write_index);
void BurstMode(void);

#endif /* CONTROLMAIN_H_ */
