
#ifndef USERINCLUDES_SOL_VARI_H_
#define USERINCLUDES_SOL_VARI_H_

//#include "F28x_Project.h"
//#include "../User_Header/def.h"

extern int TB_inveterPRD; //initial 100kHz
extern int PWM_PRD_half_INV;
extern float		PWM_Ts;
extern int OPER_MODE;
////////////////////////Revised by SD 2021.08.26//////////////////////////////////
extern int Start;
extern int theta_count;
extern double I_PFC_A_input;
extern double LPF_gain2;
extern double I_PFC_B_input;
extern double I_PFC_C_input;
extern double CT_gain;
extern double CT_gain1;
extern double CT_gain2;
extern double CT_gain3;
extern double CT_op_gain1;
extern double CT_op_gain2;
extern double CT_op_gain3;
extern double CT_offset;
extern double CT_offset1;
extern double CT_offset2;
extern double CT_offset3;
extern double V_AC_gain;
extern double V_AC_offset;
extern double V_AC_offset1;
extern double V_AC_offset2;
extern double V_AC_offset3;

extern double V_AC_gain_link;
extern double HCPL_gain;
extern double HCPL_gain1;
extern double HCPL_gain2;
extern double HCPL_gain3;

extern double I_PFC_FB;
extern double I_PFC_FB_input;
extern double DC_link_V_input;
extern double I_PFC_A;
extern double I_PFC_B;
extern double I_PFC_C;
extern double V_AC_FB;
extern double V_AC_peak;
extern double I_i_B_ref_in;
extern double I_i_A_ref_in;
extern double LPF_gain_I;
extern double VAC_freq;
extern double V_AC_gain1;
extern double V_AC_gain2;
extern double V_AC_gain3;

extern int Flag1;
extern int Flag2;
extern int Flag1_1;
extern int Flag2_1;

extern double DC_link_V_G;
extern double DC_link_V;
extern double T_timer;
extern double V_AC;
extern double VAC_abs;
extern int PFC_cnt;
extern double PI_pfc_I_V;
extern double PI_pfc_P_V;
extern double KI_pfc_V;
extern double KP_pfc_V;
extern double V_DC_ref;
extern int SW_trip;
extern double PI_pfc_V_out;
extern double PI_pfc_I_i_A;
extern double KI_pfc_i;
extern double PI_pfc_P_i_A;
extern double KP_pfc_i;
extern double PI_pfc_I_A_out;
extern double PI_pfc_I_i_B;
extern double PI_pfc_P_i_B;
extern double PI_pfc_I_B_out;
extern int PFC_Flag;
extern double LPF_gain3;
extern double  PI_pfc_I_B_out_new;
extern double  PI_pfc_I_A_out_new;
extern int I_control;

extern double V2L_sin;

extern double LPF_w, V_AC_FB_old, Vqs_LPF;
extern double PLL_Pterm, PLL_Iterm, PLL_omega;
extern double Kp_PLL, Ki_PLL;

// Burst Mode ���� ����
extern unsigned int Burst_Mode;
extern unsigned int BM_Pwm_Block;
extern unsigned int Flag_BM_Hi_Limit;
extern unsigned int Flag_BM_Lo_Limit;
extern double SET_BURST_HI_LEVEL, SET_BURST_LO_LEVEL, SET_BURST_DEL_VOLT;

#define NUM_SAMPLES 7
extern float adc_samples_I[NUM_SAMPLES];
extern int avg_index_I;
extern float adc_samples_V[NUM_SAMPLES];
extern int avg_index_V;
extern float Avg_cal_V;
extern float Avg_cal_I;

//////////////////////////////////////////////////////////////////////////////////////
extern int Iin_cnt;
extern int Trip_enable;
extern int trip_cnt;
extern int trip_ready;
extern int trip_Iin_cnt;
extern int SW_trip;
extern int Vout_cnt;
extern int trip_Vout_cnt;
extern double I_i_A_ref, I_i_A_err, I_i_B_ref, I_i_B_err;
extern int limit_cnt;

extern int Precharge;
extern int MC_on;
extern int MC_off;
extern int single_phase_mode;

//////////////////////Revised by SD 2021.09.09////////////////////////////////////////
/////PLL

extern double V_RT;
extern double V_ds_S_angle;
extern int theta_run;

extern double phase_angle;
extern double cutoff_freq;
extern double phase_angle_rad;
extern double A_inv;
extern double C_TSAMP;
extern double B_inv;
extern double V_qs_S_angle;
extern double V_ds_S_angle_old;
extern double V_qs_S_angle_old;
extern double Vds_S_angle;
extern double Vqs_S_angle;
extern double Vde_S_angleFlt;
extern double Kf1_S;
extern double Vde_S_angle0;
extern double Kf2_S;
extern double Vde_S_angle;
extern double Vde_S_angleErr;

extern double Vde_S_angleRef;
extern double Vde_S_angleFlt;

extern double We_S_angle;
extern double We_S_angleOld;
extern double KpTheta_S;
extern double KiTheta_S;
extern double Vde_S_angleErr;
extern double KpTheta_S;
extern double Vde_S_angleErr0;

//extern double Theta;
extern double We_S_angle;
extern double Vqe_S_angle;
//extern double rCOS;
//extern double rSIN;
extern double phi;
extern double LPF_gain;

extern int PLL_cnt, DEC_cnt, PFC_cnt;
extern double We_S_angle_I , We_S_angle_P;
extern double ff_theta;

extern double delt_Vout;
extern double V_DC_ref_ss;
extern int ss_cnt;



//////////////////////////////////////////V2G ����
extern float Vds;
extern float Vqs;
extern float fsw;
extern float fg;
extern float past_Vds;
extern float past_Vqs;

extern float Vde;
extern float Vqe;
extern float rtheta;

extern float rVerr;
extern float V_Pterm;
extern float V_Iterm;
extern float V_PIterm;
extern float rKp_V;
extern float rKi_V;
extern float rIL_ref;
extern float rVref;

extern float rIL1_err;
extern float IL1_Pterm;
extern float IL1_Iterm;
extern float IL1_PIterm;
extern float rIL2_err;
extern float IL2_Pterm;
extern float IL2_Iterm;
extern float IL2_PIterm;
extern float rKp_IL;
extern float rKi_IL;

extern float IL14;
extern float IL13;
extern float IL12;
extern float IL11;
extern float IL24;
extern float IL23;
extern float IL22;
extern float IL21;


extern float Po;
extern float Vac_rms;

extern  unsigned int	wCntAdca;
extern	unsigned int	wCntAdcb;
extern	unsigned int	wCntAdcc;
extern  unsigned int    wCntAdcd;

extern unsigned int	wMainCnt;
extern unsigned int	SPI_BUFF_DATA_0;
extern unsigned int	SPI_BUFF_DATA_1;
extern unsigned int	SPI_BUFF_DATA_2;
extern unsigned int	SPI_BUFF_DATA_3;

extern long	VDC_IN_AD_Integ;
extern long	VDC_BOOST_AD_Integ;
extern long	CURR_BOOST_AD_Integ;
extern long	VIN_AC_AD_Integ;
extern long	CURR_AC_AD_Integ ;
extern long CURR_AC_AD_Integ_SJ ;

extern long Test_ADCA2_Integ;
extern long Test_ADCA3_Integ;
extern long Test_ADCA4_Integ;
extern long Test_ADCA5_Integ;

extern long Test_ADCB2_Integ;
extern long Test_ADCB3_Integ;


extern	unsigned int 	SET_DAC_DATA0, SET_DAC_DATA1, SET_DAC_DATA2, SET_DAC_DATA3;
extern	unsigned int 	SET_DAC_OFFSET0, SET_DAC_OFFSET1, SET_DAC_OFFSET2, SET_DAC_OFFSET3;
extern	unsigned int	SET_DATA_TYPE0, SET_DATA_TYPE1, SET_DATA_TYPE2, SET_DATA_TYPE3;
extern	float			SET_DAC_SCALE0, SET_DAC_SCALE1, SET_DAC_SCALE2, SET_DAC_SCALE3;
extern	float			SET_VOLT_SCALE0, SET_VOLT_SCALE1, SET_VOLT_SCALE2, SET_VOLT_SCALE3;

extern	unsigned int	wVDC_IN_AD;
extern	unsigned int	wVDC_BOOST_AD;
extern	unsigned int	wCURR_BOOST_AD;
extern	unsigned int	wVIN_AC_AD;
extern	unsigned int	wCURR_AC_AD;

extern unsigned int wTest_ADCA2;
extern unsigned int wTest_ADCA3;
extern unsigned int wTest_ADCA4;
extern unsigned int wTest_ADCA5;
extern unsigned int wTest_ADCB2;
extern unsigned int wTest_ADCB3;
extern unsigned int wTest_ADCB4;


extern	float	wVDC_IN_AD_LPF;
extern	float	wVDC_IN_AD_oldLPF;
extern	float	ALPHA_wVDC_IN;

extern  float	wVDC_IN_AD_LPF_Low;
extern  float	wVDC_IN_AD_oldLPF_Low;
extern  float	ALPHA_wVDC_IN_Low;

extern	float	wVDC_BOOST_AD_LPF;
extern	float	wVDC_BOOST_AD_oldLPF;
extern	float	ALPHA_wVDC_BOOST;

extern	float   wCURR_BOOST_AD_LPF;
extern	float	wCURR_BOOST_AD_oldLPF;
extern	float	ALPHA_wCURR_BOOST;

extern	float	wVIN_AC_AD_LPF;
extern	float	wVIN_AC_AD_oldLPF;
extern	float	ALPHA_wVIN_AC;

extern	float	wCURR_AC_AD_LPF;
extern	float	wCURR_AC_AD_oldLPF;
extern	float	ALPHA_wCURR_AC;

extern	float	rVDC_INLPF,	rVDC_BOOSTLPF, rCURR_BOOSTLPF, rVIN_ACLPF, rCURR_ACLPF, rVDC_INLPF_L;

extern	float	rVDC_IN, rVDC_BOOST, rCURR_BOOST, rVIN_AC, rCURR_AC;
extern	float	rVDC_IN_SenScale, rVDC_BOOST_SenScale, rCURR_BOOST_SenScale, rVIN_AC_SenScale, rCURR_AC_SenScale;

extern float rTest_ADCA2_SenScale;
extern float rTest_ADCA3_SenScale;
extern float rTest_ADCA4_SenScale;
extern float rTest_ADCA5_SenScale;

extern float rTest_ADCB2_SenScale;
extern float rTest_ADCB3_SenScale;

extern float rTest_ADCA2, rTest_ADCA3, rTest_ADCA4, rTest_ADCA5, rTest_ADCB2, rTest_ADCB3;

extern	int	VDC_IN_AD_Offset, VDC_BOOST_AD_Offset, CURR_BOOST_AD_Offset, VIN_AC_AD_Offset, CURR_AC_AD_Offset;

extern int Test_ADCA2_Offset, Test_ADCA3_Offset, Test_ADCA4_Offset, Test_ADCA5_Offset, Test_ADCB2_Offset, Test_ADCB3_Offset;

extern	float	rFltFreqVdcBoost;
extern	float	rFltFreqVdcIN;
extern	float	rFltFreqCurrBoost;
extern	float	rFltFreqCurrAC;
extern	float	rFltFreqVAC1;
extern	float	rFlt_LowFreqVdcIN;

extern	float	TsCla;	//40khz Sampling

extern	float	rIdss;
extern	float	rIqss;
extern	float	rIdse;
extern	float	rIqse;
extern	float	rIdseRef;
extern	float	rIqseRef;
extern	float	rErrIdse;
extern	float	rErrIqse;
extern	float	rVdseAnti;
extern	float	rVqseAnti;
extern	float	rIdseRefOut;
extern	float	rIqseRefOut;
extern	float	rIdseErrPterm;
extern	float	rIqseErrPterm;
extern	float	rIdseErrIterm;
extern	float	rIqseErrIterm;
extern	float	rVRef;
extern	float	rCurKpd;
extern	float	rCurKid;
extern	float	rCurKad;
extern	float	rCurKpq;
extern	float	rCurKiq;
extern	float	rCurKaq;
extern	float	rCurAlpha;
extern	float	rDirIdse;
extern	float	rDirIqse;
extern	float	rVdseRefDeCop;
extern	float	rVqseRefDeCop;
extern	float	rVseRefMin, rVseRefMax;
extern	float	VdseRefFeedFoward;
extern	float	VqseRefFeedFoward;
extern	float	rVdseRefHighLimit, rVdseRefLowLimit;
extern	float	rVqseRefHighLimit, rVqseRefLowLimit;

extern	float	rVqseLPF, rVdseLPF, VqseOldLpf, VdseOldLpf;
extern	float	ALPHA_LPF_Vqse;
extern	float	ALPHA_LPF_Vdse;
extern	float	ALPHA_SHT;
extern	float	rVqssOldSht;
extern	float	rVdssOldSht;
extern	float	rIqssOldSht;
extern	float	rIdssOldSht;

extern	float	rKiPll,	rKpPll, Theta, Theta2, rPhase_delay_DEG2, VqseOldPLL, WeGrid;

extern	double	rSIN, rSIN2, rCOS, rCOS2;

extern	float	ThetaOffset;

extern	unsigned long	lFaultStatus;
extern	unsigned int	wBoundOC;
extern	unsigned int	wFltCountIac;
extern	unsigned int	wFltCountIboost;
extern	unsigned int	wFltCountVac;
extern	float	SET_OCT_BOOST_LEVEL, SET_OCT_AC_LEVEL, SET_OVT_VDCIN_LEVEL, SET_OVT_BOOST_LEVEL, SET_OVT_AC_LEVEL;

extern	unsigned int	ddd;
extern	unsigned int	TestDuty;
extern	unsigned int 	TestDuty_2;
extern	unsigned int 	ControlMode;
extern	unsigned int 	wPwmIsrCnt;
extern	unsigned int 	pwmcnt;
extern	unsigned int 	t_on_1st;
extern	unsigned int 	t_on_2nd;
extern	unsigned int 	dt_on;
extern	unsigned int	dt_off;

extern  unsigned int RED_TEST;
extern  unsigned int FED_TEST;
extern  unsigned int set3;
extern  unsigned int set2;
extern  unsigned int set1;
extern  unsigned int out_mode_TEST;
extern  unsigned int in_mode_TEST;
extern  unsigned int polsel_test;
extern  unsigned int reference_;
extern  unsigned int kjw;
extern  float reference_Freq;
extern  unsigned int Theta_offset;
extern  unsigned int wCntTripZone6;
extern  unsigned int wCntTripZone7;
extern	unsigned int wCntTripZone8;
extern  unsigned int FLT_BOOST;
extern unsigned int FLT_INT_OCDINT;
extern unsigned int FLT_INT_OCDENT;
extern	unsigned int RLY_STATE;
extern  float Ma;
extern  float Mf;
extern  float Theta_;
extern  float Vref;
extern	float _Vref;
extern  unsigned int RLY_CTRL;
extern  unsigned int FaultReset;
extern  unsigned int PWM_INV_SYNC;
extern	float rVboostDuty;
extern	float rBoostDuty;
extern  float DELTA_THETA;

extern	float	rRamp_step;
extern	float	rNowValue;
extern	float	V_ref;
extern	float	time;
extern	float	P_Duty;
extern	float	P_Ref;

extern	float	rErr_VBoost;
extern	float	rPterm_VBoost;
extern	float	rKp_VBoost;
extern	float	rIterm_VBoost;
extern	float	rKi_VBoost;
extern	float	rRef_VBoost;

extern	float	rErr_IBoost;
extern	float	rPterm_IBoost;
extern	float	rKp_IBoost;
extern	float	rIterm_IBoost;
extern	float	rKi_IBoost;
extern	float	rRef_IBoost;
extern	unsigned int PI_Control_Cnt;
extern float ALPHA_Vref_half, Vref_half_old, rFLTFreqVref, Vref_half;

extern	float Vac_in_old, Vac_out_old, rV_alpha, rV_beta, rVd_Conv, rVq_Conv;
extern	float rErrVq_Conv, rKpVq, rKiVq, Vq_ConvPterm, Vq_Conviterm, rRef_VqConv, rVIN_AC_phase;

extern	float rVIN_AC_outold, rVDC_outold, rVDC_BOOST_outold, rCURR_BOOST_outold;

extern	float CutOffFreq_APF;
extern	float CutOffFreq_AD;
extern	float Vref_half_in_old;
extern	float Vref_half_out_old;
extern	float sampleFreq;
extern	float Ws;
extern	float rVq_Ref;
extern	float rSin;
extern	float rCos;

extern float k_w;
extern float L_w;

extern	float rCURR_AC_phase, Iac_in_old, Iac_out_old;
extern	float rIds, rErrIds, rIdsPterm, rKpdsGain, rIdsIterm, rKidsGain, rRef_Ids_Curr, rId_Conv, rId_alpha, rId_alpha_Phase;
extern	float rIqs, rErrIqs, rIqsPterm, rKpqsGain, rIqsIterm, rKiqsGain, rRef_Iqs_Curr, rIq_Conv, rIq_beta;
extern	float rCURR_AC_FLT;
extern	float rRef_Ids;
extern	float rRef_Iqs;

extern	float rCURR_AC_outold, rCURR_AC_inold;
extern	float rId_Conv_outold, rId_Conv_inold, rIq_Conv_outold, rIq_Conv_inold, rId_Conv_LPF, rIq_Conv_LPF;
extern	float rPWM6_Ref, rPWM7_Ref, rPwmScaleFactor;
extern	unsigned int Mode_Select;
extern	float rErrVqse, rIq_alpha,  rVdse, rVdss, rVKiPLL, rVKpPLL, rVqse, rVqseErrIterm, rVqseErrPterm, rVqseRef, rVqss, rVqseRefOut;

extern	unsigned int Inverter_Start;

extern	float	rVdss_LPF, rVqss_LPF, rVdss_outold, rVqss_outold;
extern	float	rIdss_LPF, rIqss_LPF, rIdss_outold, rIqss_outold;

extern	float	rVdse_LPF, rVdse_outold, VdseCutoff;

extern	float	rVdcScaleLPF, rVdcScale_old;

extern	float bHarComp3, bHarComp5, bHarComp7, bHarComp9, bHarComp11, bHarComp13;

extern	float	rControlTime;
extern	float	rWeGridLPF;
extern	float	HAR_LIMIT;

extern	unsigned int Controlflag;
extern int Test_TBPRD;
extern int Start_Flag;
extern unsigned int ReadADcnt;

extern unsigned int theta_run_r;

extern float Theta_V2L;

//////3ph PWM ����
extern double Pwm0_ENn;
extern int short_circuit;
extern int cnt_PWM, flag1, flag2;

extern double theta_start;
extern double V_UV;
extern double V_WU;
extern double V_VW;
extern double V_U;
extern double V_V;
extern double V_W;
extern double theta_th;
extern double theta_de;
extern double Ki_Vqe;
extern double Kp_Vqe;
extern double Iq_th, Pq_th, PLL_Error, Vds_th, Vde_th, Vqe_th, Vqs_th, w_th;
extern double control_start;
extern double I_U;
extern double I_V;
extern double I_W;
extern double Ids_th, Iqs_th, Ide_th, Iqe_th;
extern int ss_cnt_th;
extern int V_count;
extern double Verror_th;
extern double Kp_vol;
extern double KI_vol;
extern double P_vol, I_vol, PI_vol;

extern double Iref_d;
extern double Ierror_d;
extern double Kp_cur_d;    //��������� P gain : d��
extern double KI_cur_d;  //��������� I gain : d��
extern double I_cur_d;
extern double P_cur_d;
extern double PI_cur_d;
extern double PI_cur_d_F;

extern double Iref_q;
extern double Ierror_q;
extern double Kp_cur_q;    //��������� P gain : q��
extern double KI_cur_q;  //��������� I gain : q��
extern double I_cur_q;
extern double P_cur_q;
extern double PI_cur_q;
extern double PI_cur_q_F;
extern double Vdeff;

extern double Ids_F;
extern double Iqs_F;
extern double IU_ref;
extern double IV_ref;
extern double IW_ref;
extern double Min;
extern double Max;
extern double VU_ref;
extern double VV_ref;
extern double VW_ref;
extern double Vmm;

extern Uint16 wtest_flag;

#endif
