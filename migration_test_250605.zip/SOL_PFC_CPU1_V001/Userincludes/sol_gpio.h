
#ifndef USERINCLUDES_SOL_GPIO_H_
#define USERINCLUDES_SOL_GPIO_H_

extern void InitUserGpio(void);
extern void Input_XBarInit(void);
extern void EpwmXbar_Init(void);

// 7K3 concept1 board LED
#define	LED1_OFF				    GpioDataRegs.GPCCLEAR.bit.GPIO93 = 1
#define	LED1_ON					    GpioDataRegs.GPCSET.bit.GPIO93 = 1
#define	LED1_TOGGLE				    GpioDataRegs.GPCTOGGLE.bit.GPIO93 = 1

#define	LED2_OFF				    GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1
#define	LED2_ON					    GpioDataRegs.GPCSET.bit.GPIO94 = 1
#define	LED2_TOGGLE				    GpioDataRegs.GPCTOGGLE.bit.GPIO94 = 1

// AC Main relay
#define	RLY_OFF					    GpioDataRegs.GPCCLEAR.bit.GPIO0 = 1
#define	RLY_ON					    GpioDataRegs.GPCSET.bit.GPIO0 = 1

// EVM LED TEST
#define EVM_GPIO32_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO32 = 1
#define EVM_GPIO32_ON               GpioDataRegs.GPBSET.bit.GPIO32 = 1
#define EVM_GPIO32_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO32 = 1

#define EVM_GPIO33_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO33 = 1
#define EVM_GPIO33_ON               GpioDataRegs.GPBSET.bit.GPIO33 = 1
#define EVM_GPIO33_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO33 = 1

#define EVM_GPIO34_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1
#define EVM_GPIO34_ON               GpioDataRegs.GPBSET.bit.GPIO34 = 1
#define EVM_GPIO34_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1

#define EVM_GPIO35_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO35 = 1
#define EVM_GPIO35_ON               GpioDataRegs.GPBSET.bit.GPIO35 = 1
#define EVM_GPIO35_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO35 = 1

#define EVM_GPIO36_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO36 = 1
#define EVM_GPIO36_ON               GpioDataRegs.GPBSET.bit.GPIO36 = 1
#define EVM_GPIO36_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO36 = 1

#define EVM_GPIO37_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO37 = 1
#define EVM_GPIO37_ON               GpioDataRegs.GPBSET.bit.GPIO37 = 1
#define EVM_GPIO37_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO37 = 1

#define EVM_GPIO38_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO38 = 1
#define EVM_GPIO38_ON               GpioDataRegs.GPBSET.bit.GPIO38 = 1
#define EVM_GPIO38_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO38 = 1

#define EVM_GPIO39_OFF              GpioDataRegs.GPBCLEAR.bit.GPIO39 = 1
#define EVM_GPIO39_ON               GpioDataRegs.GPBSET.bit.GPIO39 = 1
#define EVM_GPIO39_TOGGLE           GpioDataRegs.GPBTOGGLE.bit.GPIO39 = 1
//


#endif /* GPIO_H_ */
