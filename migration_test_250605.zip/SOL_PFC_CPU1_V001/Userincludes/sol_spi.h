
#ifndef USERINCLUDES_SOL_SPI_H_
#define USERINCLUDES_SOL_SPI_H_

extern void InitSpi(void);
extern void InitSpi_DAC(void);


#endif /* SOURCE_USER_HEADER_SPI_H_ */
