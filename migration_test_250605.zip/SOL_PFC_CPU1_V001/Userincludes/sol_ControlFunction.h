
#ifndef USERINCLUDES_SOL_CONTROLFUNCTION_H_
#define USERINCLUDES_SOL_CONTROLFUNCTION_H_

#define LPF(in, out, old, fc, Ts)			{				\
   float tau;												\
   	   	   	   	   	   	   	   	   	   	   	   	   	    	\
   tau = 1/(2*3.141592*fc);									\
   	   	   	   	   	   	   	   	   	   	   	   	   	    	\
   out = ((tau*(old))+(Ts*in))/(tau+Ts);					\
   old = out;												\
}

#define Ramp_Step(Vref, Output, Ts, time)					\
		Output = (Vref * Ts) / time;

#define	Ramp_function(target, ramp, delInc, max, min)	\
	if(target == 0) ramp = 0;							\
	if(target > max) target = max;						\
	if(target < min) target = min;						\
	if(ramp < min) ramp = min;							\
	if(ramp < target)									\
	{														\
		if	(target - ramp > delInc)	ramp += delInc;		\
		else 							ramp = target;	}	\
	else												\
	{													\
		if	(ramp - target > delInc)	ramp -= delInc;		\
		else							ramp = target;		\
	}

#define PI_Control(Err, Ref, Sen, Pterm, Iterm, Output, FF, Max, Min, Kp, Ki, Ts)				\
		Err = Ref - Sen;				\
		Pterm = Err * Kp;					\
		Iterm += Err * Ki * Ts;				\
		if(Iterm > Max)		Iterm = Max;	\
		if(Iterm < Min)		Iterm = Min;	\
		Output = Pterm + Iterm + FF;				\
		if(Output > Max)	Output = Max;	\
		if(Output < Min)	Output = Min;

#define Boost_FF(Ref, Sen, Duty, Output, PRD)			\
		Duty = 1 - (Sen / Ref);						\
		Output = (unsigned int) (PRD * Duty);

#define AB_TO_DQ(alpha, beta, Id, Iq, SIN, COS)	\
		Id = SIN * alpha - COS * beta;	\
		Iq = COS * alpha + SIN * beta;

#define DQ_TO_AB(Id, Iq, alpha, beta, SIN, COS)			\
		alpha = SIN * Id + COS * Iq;		\
		beta  = -(COS * Id) + SIN * Iq;

#define PLL(Err, Ref, Sen, Pterm, Iterm, Kp, Ki, Ts, Max, Min, Output, Ws, Theta, Theta2, Offset, SIN, COS)	\
		Err = Ref + Sen; \
		Pterm = Err * Kp;	\
		Iterm += Err * Ki * Ts; \
		if(Iterm > Max)		Iterm = Max;		\
		if(Iterm < Min)		Iterm = Min;		\
		Output = Pterm + Iterm + Ws;			\
		if(Output > Max)	Output = Max;		\
		if(Output < Min)	Output = Min;		\
		Theta += Output * Ts;					\
		Theta2 = Theta + Offset/180*PI;			\
		if(Theta > PI2)		Theta = 0;			\
		if(Theta2 > PI2)	Theta2 = 0;			\
		SIN = sin(Theta2);						\
		COS = cos(Theta2);

#endif /* SOURCE_USER_HEADER_CONTROLFUNCTION_H_ */
