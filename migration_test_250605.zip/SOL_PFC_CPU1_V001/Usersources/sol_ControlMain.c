#include "base.h"

#pragma CODE_SECTION (PWM_ISR,".TI.ramfunc")
#pragma CODE_SECTION (protection,".TI.ramfunc")

int PHASE_8 = 2500, CMPAA = 0, CMPBB = 0, Phase_test = 0;
int PWM_TEST = 0, Test_CMPA_B = 0, AC_pole = 0, DTVARI = 125, DTVARI2 = 0;
float a1 = 0, b0 = 0, b1 = 0, w0 = 0;
int sync_test = 0;
int TEST_sync_PRD = 2000;
int PWM_TESTTT = 0;
int TESTMA = 500;
float TEST_SIN = 0, PI_FF = 0, counttttt = 0, Theta_abs = 0, rSIN_F = 0;
int OCT_3ph = 0;
double OCT_LEVEL = 30;

int wtest_flg;

void LPF_1_Order(float Sampling_Time, float pole, double LPF_Input, double *LPF_Output)
{
    *LPF_Output += pole * (LPF_Input - *LPF_Output) * Sampling_Time;
}

interrupt void PWM_ISR(void) // 40khz(25us)
{
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER3.all;
    IER |= M_INT3;
    IER &= MINT3;                       // Set "global" priority
    PieCtrlRegs.PIEIER3.all &= MG3_4;   // Set "group"  priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;    // Enable PIE interrupts
    EINT;

    wPwmIsrCnt++;

    ReadAD();

    // 2-phase Interleaved totem-pole ACIN Voltage
    V_AC_FB = ((((double)wTest_ADCA4 * 0.000811 - V_AC_offset2) * V_AC_gain2) * HCPL_gain2) * 3226.8;
    V_AC = LPF_gain * V_AC + (1 - LPF_gain) * V_AC_FB;
    VAC_abs = abs(V_AC);

    // 3-phase PWM ACIN Voltage
//    V_UV = (((wTest_ADCA2 * 0.000811 - V_AC_offset1) * V_AC_gain1) * HCPL_gain1) * 3031.3;
//    V_VW = (((wTest_ADCA3 * 0.000811 - V_AC_offset2) * V_AC_gain2) * HCPL_gain2) * 3031.3;
//    V_WU = (((wTest_ADCA4 * 0.000811 - V_AC_offset3) * V_AC_gain3) * HCPL_gain3) * 3031.3;

    // ACIN Current
    I_PFC_A_input = ((((double)wTest_ADCA3 * 0.000811) * CT_op_gain1) - CT_offset1) * CT_gain1; // A current
    I_PFC_B_input = ((((double)wTest_ADCA5 * 0.000811) * CT_op_gain2) - CT_offset2) * CT_gain2; // B current
    I_PFC_C_input = ((((double)wTest_ADCB3 * 0.000811) * CT_op_gain3) - CT_offset3) * CT_gain3; // back current
//    I_PFC_FB_input = (((wTest_ADCB4 * 0.000811)*CT_gain) - CT_offset) * 50; //-CT_offset* CT_gain2;
    DC_link_V_input = ((((double)wTest_ADCB4 * 0.000811) * V_AC_gain_link) * HCPL_gain2) * 5518.205; //DCLINK
//    DC_link_V_input = (rTest_ADCB2) * DC_link_V_G;

    // Low-pass-filter
    I_PFC_A = LPF_gain_I * I_PFC_A + (1 - LPF_gain_I) * I_PFC_A_input;
    I_PFC_B = LPF_gain_I * I_PFC_B + (1 - LPF_gain_I) * I_PFC_B_input;
    I_PFC_C = LPF_gain_I * I_PFC_C + (1 - LPF_gain_I) * I_PFC_C_input;
    I_PFC_FB = LPF_gain * I_PFC_FB + (1 - LPF_gain) * I_PFC_FB_input;
    DC_link_V = LPF_gain2 * DC_link_V + (1 - LPF_gain2) * DC_link_V_input;

//    IA_abs = abs(I_PFC_A);
//    IB_abs = abs(I_PFC_B);

    rSIN_F = LPF_gain3 * rSIN + (1 - LPF_gain3) * rSIN;

    // burst mode check (�Է� ������ üũ)
    if(I_PFC_A >= 2 || I_PFC_B >= 2)    Burst_Mode=0; // 1A �̻�(���� �� 2A�̻�) burst off
    else                                Burst_Mode=1; // 1A ����(0A, ������)�� burst on

    SET_BURST_HI_LEVEL  = V_DC_ref_ss + SET_BURST_DEL_VOLT;     // DC������� Burst upper limit
    SET_BURST_LO_LEVEL  = V_DC_ref_ss - SET_BURST_DEL_VOLT;     // DC������� Burst below limit

    // Start
    if (Start == 1 && V_AC >= 3 && V_AC <= 10)
    {
        PFC_Flag = 1;
    }
#ifdef __G2V_mode
    // PFC Closed Loop
    if (Start_Flag == 1) // G2V mode
    {
        Theta_abs = fabs(rSIN_F);

        if (PFC_Flag == 1)
        {
            PFC_cnt++;
            if (PFC_cnt == 1)
            {
                if (SW_trip == 0)
                {
                    PFC_cnt = 0;
                    ss_cnt++;
                    if (ss_cnt == 50) //soft start
                    {
                        ss_cnt = 0;
                        if ((V_DC_ref - V_DC_ref_ss) > delt_Vout)
                        {
                            V_DC_ref_ss += delt_Vout;
                        }
                        else if ((V_DC_ref - V_DC_ref_ss) < -delt_Vout)
                        {
                            V_DC_ref_ss -= delt_Vout;
                        }
                        else
                        {
                            V_DC_ref_ss = V_DC_ref;
                        }
                    }

                    // Voltage I cal
                    PI_pfc_I_V += KI_pfc_V * (V_DC_ref_ss - DC_link_V) * 0.00002;
                    if (PI_pfc_I_V > 100) // Limit
                    {
                        PI_pfc_I_V = 100;
                    }
                    if (PI_pfc_I_V < 0)
                    {
                        PI_pfc_I_V = 0;
                    }
                    // Voltage P cal
                    PI_pfc_P_V = KP_pfc_V * +(V_DC_ref_ss - DC_link_V);
                    // merge PI
                    PI_pfc_V_out = PI_pfc_I_V + PI_pfc_P_V;
                    if (PI_pfc_V_out > 65) // Limit
                    {
                        PI_pfc_V_out = 65;
                    }
                    if (PI_pfc_V_out < 0)
                    {
                        PI_pfc_V_out = 0;
                    }

                    // A-phase current controller
                    I_i_A_ref_in = PI_pfc_V_out * fabs(rSIN); // A-phase Current reference
                    I_i_A_ref = LPF_gain_I * I_i_A_ref + (1 - LPF_gain_I) * I_i_A_ref_in; // LPF

                    // Current ref - Real Current
                    I_i_A_err = I_i_A_ref - abs(I_PFC_A);
                    PI_pfc_I_i_A += KI_pfc_i * (I_i_A_err) * 0.000025; // Current I cal
                    if (PI_pfc_I_i_A > Test_TBPRD)
                    {
                        PI_pfc_I_i_A = Test_TBPRD;
                    }
                    if (PI_pfc_I_i_A < 0)
                    {
                        PI_pfc_I_i_A = 0;
                    }

                    PI_pfc_P_i_A = KP_pfc_i * (I_i_A_err); // Current P cal
//                    PI_pfc_P_i_A_new=LPF_gain3*PI_pfc_P_i_A_new+(1-LPF_gain3)*PI_pfc_P_i_A;

                    // PWM control
                    PI_pfc_I_A_out = PI_pfc_I_i_A + PI_pfc_P_i_A + (1 - (V_AC_peak * fabs(rSIN)) / V_DC_ref_ss) * Test_TBPRD;
//                    PI_pfc_I_A_out = (1-(V_AC_peak*fabs(rSIN_F))/V_DC_ref_ss)*Test_TBPRD; //FF�� ����

                    PI_FF = (1 - (V_AC_peak * fabs(rSIN_F)) / V_DC_ref) * Test_TBPRD;

                    if (PI_pfc_I_A_out > Test_TBPRD * 0.98)
                    {
                        PI_pfc_I_A_out = Test_TBPRD * 0.98;
                    }
                    if (PI_pfc_I_A_out < 0)
                    {
                        PI_pfc_I_A_out = 0;
                    }
                    PI_pfc_I_A_out_new = LPF_gain3 * PI_pfc_I_A_out_new + (1 - LPF_gain3) * PI_pfc_I_A_out;

                    // B-phase current controller
//                    I_i_B_ref_in=PI_pfc_V_out*VAC_abs/V_AC_peak;
                    I_i_B_ref_in = PI_pfc_V_out * fabs(rSIN); // B-phase Current reference
                    I_i_B_ref = LPF_gain_I * I_i_B_ref + (1 - LPF_gain_I) * I_i_B_ref_in; // LPF

                    // Current ref - Real Current
                    I_i_B_err = I_i_B_ref - abs(I_PFC_B);
                    PI_pfc_I_i_B += KI_pfc_i * (I_i_B_err) * 0.000025; // Current I cal
                    if (PI_pfc_I_i_B > Test_TBPRD)
                    {
                        PI_pfc_I_i_B = Test_TBPRD;
                    }
                    if (PI_pfc_I_i_B < 0)
                    {
                        PI_pfc_I_i_B = 0;
                    }

                    PI_pfc_P_i_B = KP_pfc_i * (I_i_B_err); // Current P cal
//                    PI_pfc_P_i_B_new=LPF_gain3*PI_pfc_P_i_B_new+(1-LPF_gain3)*PI_pfc_P_i_B;

                    // PWM control
                    PI_pfc_I_B_out = PI_pfc_I_i_B + PI_pfc_P_i_B + (1 - (V_AC_peak * fabs(rSIN)) / V_DC_ref_ss) * Test_TBPRD;
//                    PI_pfc_I_B_out = (1-(V_AC_peak*fabs(rSIN_F))/V_DC_ref_ss)*Test_TBPRD; //FF�� ����

                    if (PI_pfc_I_B_out > Test_TBPRD * 0.98)
                    {
                        PI_pfc_I_B_out = Test_TBPRD * 0.98;
                        limit_cnt++;
                    }
                    if (PI_pfc_I_B_out < 0)
                    {
                        PI_pfc_I_B_out = 0;
                    }
                    PI_pfc_I_B_out_new = LPF_gain3 * PI_pfc_I_B_out_new + (1 - LPF_gain3) * PI_pfc_I_B_out;

                    //Totem-pole pfc controller
                    if(BM_Pwm_Block == 0) // burst
                    {
                        if (V_AC > 0)    //V_AC V_AC > 0  rSIN<0
                        {
                            PWM_ENB;
                            EPwm7Regs.CMPA.bit.CMPA = 0;
                            EPwm7Regs.CMPB.bit.CMPB = (Uint16)PI_pfc_I_A_out;
                            EPwm8Regs.CMPA.bit.CMPA = 0;
                            EPwm8Regs.CMPB.bit.CMPB = (Uint16)PI_pfc_I_B_out;
                        }
                        if (V_AC < 0)    // V_AC < 0
                        {
                            PWM_ENB;
                            EPwm7Regs.CMPA.bit.CMPA = (Uint16)PI_pfc_I_A_out;
                            EPwm7Regs.CMPB.bit.CMPB = 0;
                            EPwm8Regs.CMPA.bit.CMPA = (Uint16)PI_pfc_I_B_out;
                            EPwm8Regs.CMPB.bit.CMPB = 0;
                        }
                    }
                    else
                    {
                        PWM_BLK;
                        PI_pfc_I_V=0;
                        PI_pfc_I_i_A=0;
                        PI_pfc_I_i_B=0;
                    }

                    //�������� ����
                    if (Flag2_1 == 1)   // rSIN < -0.1
                    {
                        EPwm9Regs.CMPA.bit.CMPA = 0; //Test_TBPRD;
                        EPwm9Regs.CMPB.bit.CMPB = Test_TBPRD + 10; //TEST_sync_PRD; //2000; //Test_TBPRD+10; //0;
                    }
                    if (Flag2_1 == 0) // rSIN >= -0.1
                    {
                        //   EPwm9Regs.CMPA.bit.CMPA = 0; //TEST_sync_PRD; //2000; //Test_TBPRD+10; //0;
                        EPwm9Regs.CMPB.bit.CMPB = 0; //Test_TBPRD+10;
                    }
                    if (Flag1_1 == 1)  // rSIN > 0.1
                    {
                        EPwm9Regs.CMPA.bit.CMPA = Test_TBPRD + 10; //TEST_sync_PRD; //2000; //Test_TBPRD+10; //0;
                        EPwm9Regs.CMPB.bit.CMPB = 0; //Test_TBPRD+10;
                    }
                    if (Flag1_1 == 0)   // rSIN <= 0.1
                    {
                        EPwm9Regs.CMPA.bit.CMPA = 0; //TEST_sync_PRD; //2000; //Test_TBPRD+10; //0;
                        // EPwm9Regs.CMPB.bit.CMPB = 0;//Test_TBPRD+10;
                    }
                    if (rSIN > 0.15)
                    {
                        Flag1++;
                        if (Flag1 >= 20)
                        {
                            Flag1_1 = 1;
                        }
                        Flag2 = 0;
                        Flag2_1 = 0;
                    }
                    if (rSIN < -0.15)
                    {
                        Flag2++;
                        if (Flag2 >= 20)
                        {
                            Flag2_1 = 1;
                        }
                        Flag1 = 0;
                        Flag1_1 = 0;
                    }
                    if (rSIN >= -0.15 && rSIN <= 0.15)
                    {
                        Flag2 = 0;
                        Flag2_1 = 0;
                        Flag1 = 0;
                        Flag1_1 = 0;
                    }
                }
            }
        }
    }
#elif __V2L_mode
    Theta_V2L += 2 * PI * fg * (1 / fsw);
    if (Theta_V2L >= 2 * PI)
    {
        Theta_V2L = 0;
    }
    V2L_sin = sin(Theta_V2L);

    //rtheta ---> Theta_V2L �� �ٲ�
    if(Start_Flag == 2) // V2L mode
    {
        if (PFC_Flag == 1)
        {
            PWM_ENB;

            rVerr = rVref - Vde;
            V_Pterm = rVerr * rKp_V;
            V_Iterm += rVerr * rKi_V * (1 / fsw);
            V_PIterm = V_Pterm + V_Iterm;

            if (V_PIterm >= 150)
            {
                V_PIterm = 150;
            }
            if (V_PIterm <= -150)
            {
                V_PIterm = -150;
            }
//
            rIL_ref = V_PIterm * fabs(sin(Theta_V2L));

            rIL1_err = rIL_ref - fabs(I_PFC_A);
            IL1_Pterm = rIL1_err * rKp_IL;
            IL1_Iterm += rIL1_err * rKi_IL * (1 / fsw);
            IL1_PIterm = IL1_Pterm + IL1_Iterm + (rVref * fabs(sin(Theta_V2L)) / DC_link_V) * Test_TBPRD;

            if (IL1_PIterm >= Test_TBPRD)
            {
                IL1_PIterm = Test_TBPRD;
            }
            if (IL1_PIterm <= 0)
            {
                IL1_PIterm = 0;
            }

            rIL2_err = rIL_ref - fabs(I_PFC_B);
            IL2_Pterm = rIL2_err * rKp_IL;
            IL2_Iterm += rIL2_err * rKi_IL * (1 / fsw);
            IL2_PIterm = IL2_Pterm + IL2_Iterm + (rVref * fabs(sin(Theta_V2L)) / DC_link_V) * Test_TBPRD;

            if (IL2_PIterm >= Test_TBPRD)
            {
                IL2_PIterm = Test_TBPRD;
            }
            if (IL2_PIterm <= 0)
            {
                IL2_PIterm = 0;
            }

            if (sin(Theta_V2L) >= 0)
            {
                EPwm7Regs.CMPA.bit.CMPA = IL1_PIterm;
                EPwm7Regs.CMPB.bit.CMPB = 0;
                EPwm8Regs.CMPA.bit.CMPA = IL2_PIterm;
                EPwm8Regs.CMPB.bit.CMPB = 0;
                EPwm9Regs.CMPA.bit.CMPA = 0;
                EPwm9Regs.CMPB.bit.CMPB = Test_TBPRD;

            }
            if (sin(Theta_V2L) < 0)
            {
                EPwm7Regs.CMPA.bit.CMPA = 0;
                EPwm7Regs.CMPB.bit.CMPB = IL1_PIterm;
                EPwm8Regs.CMPA.bit.CMPA = 0;
                EPwm8Regs.CMPB.bit.CMPB = IL2_PIterm;
                EPwm9Regs.CMPA.bit.CMPA = Test_TBPRD;
                EPwm9Regs.CMPB.bit.CMPB = 0;
            }
        }
    }

#elif __V2G_mode
    if(Start_Flag == 3) // V2G mode
    {
        if(PFC_Flag == 1)
        {
            PWM_ENB;

            rIL_ref = Po * 1000 * 0.5 * (1 / Vac_rms) * sqrt(2) * fabs(sin(rtheta));

            rIL1_err = rIL_ref - fabs(I_PFC_A);

            //Anti wind-up IL1
            IL14 = rIL1_err - IL13;
            IL1_Pterm = IL14 * rKp_IL;
            IL1_Iterm += IL14 * rKi_IL * (1 / fsw);
            if (IL1_Iterm >= Test_TBPRD)
            {
                IL1_Iterm = Test_TBPRD;
            }
            if (IL1_Iterm <= 0)
            {
                IL1_Iterm = 0;
            }
            IL1_PIterm = IL1_Pterm + IL1_Iterm + (Vac_rms * sqrt(2) * fabs(sin(rtheta)) / DC_link_V) * Test_TBPRD;
            IL11 = IL1_PIterm;

            if (IL1_PIterm >= Test_TBPRD)
            {
                IL1_PIterm = Test_TBPRD;
            }
            if (IL1_PIterm <= 0)
            {
                IL1_PIterm = 0;
            }
            IL12 = IL11 - IL1_PIterm;
            IL13 = IL12 / rKp_IL; //PSIM �����δ� IL1_Pterm���� ����� ����

            rIL2_err = rIL_ref - fabs(I_PFC_B);

            //Anti wind-up IL2
            IL24 = rIL2_err - IL23;
            IL2_Pterm = IL24 * rKp_IL;
            IL2_Iterm += IL24 * rKi_IL * (1 / fsw);
            if (IL2_Iterm >= Test_TBPRD)
            {
                IL2_Iterm = Test_TBPRD;
            }
            if (IL2_Iterm <= 0)
            {
                IL2_Iterm = 0;
            }
            IL2_PIterm = IL2_Pterm + IL2_Iterm + (Vac_rms * sqrt(2) * fabs(sin(rtheta)) / DC_link_V) * Test_TBPRD;
            IL21 = IL2_PIterm;
            if (IL2_PIterm >= Test_TBPRD)
            {
                IL2_PIterm = Test_TBPRD;
            }
            if (IL2_PIterm <= 0)
            {
                IL2_PIterm = 0;
            }
            IL22 = IL21 - IL2_PIterm;
            IL23 = IL22 / rKp_IL; //PSIM �����δ� IL2_Pterm���� ����� ����

            //if((-1)*sin(rtheta)>= 0)
            if ((-1) * sin(rtheta) >= 0)
            {
                EPwm7Regs.CMPA.bit.CMPA = IL1_PIterm;
                EPwm7Regs.CMPB.bit.CMPB = 0;
                EPwm8Regs.CMPA.bit.CMPA = IL2_PIterm;
                EPwm8Regs.CMPB.bit.CMPB = 0;
                EPwm9Regs.CMPA.bit.CMPA = 0;
                EPwm9Regs.CMPB.bit.CMPB = Test_TBPRD;
            }

            //if((-1)*sin(rtheta) < 0)
            if ((-1) * sin(rtheta) < 0)
            { //
                EPwm7Regs.CMPA.bit.CMPA = 0;
                EPwm7Regs.CMPB.bit.CMPB = IL1_PIterm;
                EPwm8Regs.CMPA.bit.CMPA = 0;
                EPwm8Regs.CMPB.bit.CMPB = IL2_PIterm;
                EPwm9Regs.CMPA.bit.CMPA = Test_TBPRD;
                EPwm9Regs.CMPB.bit.CMPB = 0;
            }
        }
    }

#endif
    //3ph.PWM
#ifdef __3ph_mode
    V_U = 0.333333 * (V_UV - V_WU);
    V_V = 0.333333 * (V_VW - V_UV);
    V_W = 0.333333 * (V_WU - V_VW);

    if (Start_Flag == 6)
    {
        if (short_circuit == 1)
        {
            cnt_PWM++;
            if (cnt_PWM == 1)
            {
                Pwm0_ENn = 0;
                EPwm1Regs.CMPA.bit.CMPA = 1455;
                EPwm1Regs.DBCTL.bit.POLSEL = 0;
                flag1 = 1;
            }

            else if (cnt_PWM == 2)
            {
                EPwm1Regs.CMPA.bit.CMPA = 1499;
                EPwm1Regs.DBCTL.bit.POLSEL = 2;
                flag2 = 1;
            }
        }

        if (theta_start == 1)
        {
            //PWM_ENB;
            Vds_th = (V_U - (V_V * 0.5) - (V_W * 0.5)) * 0.666667; //������ǥ�� (Clark ��ȯ)
            Vqs_th = 0.5773502 * (V_V - V_W);

            Vde_th = Vds_th * sin(theta_th) - Vqs_th * cos(theta_th); //������ǥ��->ȸ����ǥ�� (Park ��ȯ)
            Vqe_th = Vds_th * cos(theta_th) + Vqs_th * sin(theta_th);

            LPF_1_Order(1 / 25000, PI * 2 * 10., Vde_th, &Vde_th); //��ܿ� LPF_1_Order ����
            LPF_1_Order(1 / 25000, PI * 2 * 10., Vqe_th, &Vqe_th);

            PLL_Error = Vqe_th;
            Pq_th = PLL_Error * Kp_Vqe;                            // PI Control
            Iq_th += PLL_Error * Ki_Vqe * 0.00004;                    //0.000025

            w_th = (Pq_th + Iq_th);

            //w_th = 377;/////////////////////////

            if (w_th > 400)
            {
                w_th = 400;
            }

            else if (w_th < 340)
            {
                w_th = 340;
            }

            theta_th = theta_th + (w_th * 0.00004) + theta_de; //0.000025 -> 0.0004 //0.00004                      // Integral Omega

            if (theta_th >= 2 * PI)
            {
                theta_th = 0;
                //theta_th -= 2 * PI;
            }

            else if (theta_th <= 0)
            {
                theta_th += 2 * PI;
                //theta_th = 0;
            }

            TEST_SIN = sin(theta_th);

            if (PFC_Flag == 1 && theta_th < 0.1)           // Feed Forward start
            {
                if (control_start == 0)
                {
                    control_start = 1;
                }
            }
            if (control_start == 0)
            {
                PWM_BLK;
                Vdeff = Vde_th;
                //Vqeff = Vqe;
            }
            if (control_start == 1)
            {

                //  Pwm0_ENn = 0;                                               //PWM enable
                //  GpioDataRegs.GPCDAT.bit.GPIO64 = 0;

                //  Pwm0_ENn = 0;
                PWM_ENB;
                //              Ids_th = ((-1)*I_PFC_A_input - ((-1)*I_PFC_B_input * 0.5) - ((-1)*I_PFC_C_input * 0.5)) * 0.666667;     //������ǥ�� (Clark ��ȯ)

//                Iqs_th = 0.57773502 * ((-1)*I_PFC_B_input - (-1)*I_PFC_C_input);

                Ids_th = ((-1) * I_PFC_A - ((-1) * I_PFC_B * 0.5) - ((-1) * I_PFC_C * 0.5)) * 0.666667; //������ǥ�� (Clark ��ȯ)

                Iqs_th = 0.57773502 * ((-1) * I_PFC_B - (-1) * I_PFC_C);

                Ide_th = Ids_th * sin(theta_th) - Iqs_th * cos(theta_th); //������ǥ�� -> ȸ����ǥ�� (Park ��ȯ)

                Iqe_th = Ids_th * cos(theta_th) + Iqs_th * sin(theta_th);

                ss_cnt_th++;

                if (ss_cnt_th == 5)
                {
                    ss_cnt_th = 0;

                    if ((V_DC_ref - V_DC_ref_ss) > delt_Vout)
                    {
                        V_DC_ref_ss += delt_Vout;
                    }

                    else if ((V_DC_ref - V_DC_ref_ss) < -delt_Vout)
                    {
                        V_DC_ref_ss -= delt_Vout;
                    }

                    else
                    {
                        V_DC_ref_ss = V_DC_ref;
                    }
                }

                V_count++;

                if (V_count == 5)
                {
                    Verror_th = V_DC_ref_ss - DC_link_V;
                    P_vol = Verror_th * Kp_vol;
                    I_vol = I_vol + KI_vol * Verror_th * 0.000025;

                    if (I_vol >= 150.0) //120
                    {
                        I_vol = 150.0;
                    }
//
                    else if (I_vol <= -150.0)
                    {
                        I_vol = -150.0;
                    }

                    PI_vol = P_vol + I_vol;
                    V_count = 0;                         // PI Control : Voltage
                }

                Iref_d = PI_vol;
                Ierror_d = (-1) * (Iref_d - Ide_th);
                P_cur_d = Ierror_d * Kp_cur_d;
                I_cur_d = I_cur_d + KI_cur_d * Ierror_d * 0.000025;

                if (I_cur_d >= Test_TBPRD)                  //3000 -> Test_TBPRD
                {
                    I_cur_d = Test_TBPRD;                   //3000 -> Test_TBPRD
                }

                if (I_cur_d <= -Test_TBPRD)                 //3000 -> Test_TBPRD
                {
                    I_cur_d = -Test_TBPRD;                  //3000 -> Test_TBPRD
                }

                PI_cur_d = P_cur_d + I_cur_d;        // PI Control : Current (D)
                PI_cur_d_F = PI_cur_d + Vdeff; //-Vde //+ Vde;                            // Feed Forward control

                if (PI_cur_d_F > Test_TBPRD)                //3000 -> Test_TBPRD
                {
                    PI_cur_d_F = Test_TBPRD;                //3000 -> Test_TBPRD
                }
                else if (PI_cur_d_F < -Test_TBPRD)          //3000 -> Test_TBPRD
                {
                    PI_cur_d_F = -Test_TBPRD;               //3000 -> Test_TBPRD
                }

                Iref_q = 0;
                Ierror_q = (-1) * (Iref_q - Iqe_th);
                P_cur_q = Ierror_q * Kp_cur_q;
                I_cur_q = I_cur_q + KI_cur_q * Ierror_q * 0.000025;
                PI_cur_q = P_cur_q + I_cur_q;        // PI Control : Current (Q)
                PI_cur_q_F = PI_cur_q; // +Vqeff;// + Vqe;    //+ Vqe                         // Feed Forward control

                if (PI_cur_q_F > Test_TBPRD) //3000 -> Test_TBPRD
                {
                    PI_cur_q_F = Test_TBPRD; //3000 -> Test_TBPRD
                }
                else if (PI_cur_q_F < -Test_TBPRD) //3000 -> Test_TBPRD
                {
                    PI_cur_q_F = -Test_TBPRD; //3000 -> Test_TBPRD
                }

                ///////////////////////////////////////////////////////////////////////////////////////////
                //////////////////////////Inverse D-Q Transform + Min Max Control//////////////////////////

                Ids_F = PI_cur_d_F * sin(theta_th) + PI_cur_q_F * cos(theta_th);
                Iqs_F = (-1) * PI_cur_d_F * cos(theta_th) + PI_cur_q_F * sin(theta_th);

                //               Ids_F = Vdeff * sin(theta_th);

//                Iqs_F = (-1) * Vdeff * cos(theta_th);

                // Scale O
                IU_ref = Ids_F / V_DC_ref * Test_TBPRD; //3000;   //  ����� ���/�������� * TBPRD
                IV_ref = ((-0.5) * Ids_F + 0.866025 * Iqs_F) / V_DC_ref * Test_TBPRD; //3000;
                IW_ref = ((-0.5) * Ids_F - 0.866025 * Iqs_F) / V_DC_ref * Test_TBPRD; //3000;

                if (IU_ref > IV_ref)
                {
                    Max = IU_ref;
                    Min = IV_ref;
                }
                else
                {
                    Max = IV_ref;
                    Min = IU_ref;
                }

                if (Max < IW_ref)
                {
                    Max = IW_ref;
                }

                if (Min > IW_ref)
                {
                    Min = IW_ref;
                }

                Vmm = (Max + Min) * 0.5;
                VU_ref = IU_ref - Vmm + (Test_TBPRD * 0.5);
                VV_ref = IV_ref - Vmm + (Test_TBPRD * 0.5);
                VW_ref = IW_ref - Vmm + (Test_TBPRD * 0.5);

                if (VU_ref > Test_TBPRD)
                {
                    VU_ref = Test_TBPRD;
                }

                else if (VU_ref < 0)
                {
                    VU_ref = 0;
                }

                if (VV_ref > Test_TBPRD)
                {
                    VV_ref = Test_TBPRD;
                }

                else if (VV_ref < 0)
                {
                    VV_ref = 0;
                }

                if (VW_ref > Test_TBPRD)
                {
                    VW_ref = Test_TBPRD;
                }

                else if (VW_ref < 0)
                {
                    VW_ref = 0;
                }

                EPwm7Regs.CMPA.bit.CMPA = VU_ref;
                EPwm8Regs.CMPA.bit.CMPA = VV_ref;
                EPwm9Regs.CMPA.bit.CMPA = VW_ref;
            }
        }
    }
#endif

    if(Start_Flag == 5) // operation off
    {
        EPwm7Regs.CMPA.bit.CMPA = 0;
        EPwm7Regs.CMPB.bit.CMPB = 0;
        EPwm8Regs.CMPA.bit.CMPA = 0;
        EPwm8Regs.CMPB.bit.CMPB = 0;
        EPwm9Regs.CMPA.bit.CMPA = 0;
        EPwm9Regs.CMPB.bit.CMPB = 0;
        TIMER0_us(100);
        PWM_BLK;
    }

    DAC_OUT();

//	OutputControl();
    EPwm4Regs.ETCLR.bit.INT = 1;	 // ePWM ���ͷ�Ʈ �÷��� Ŭ����
    PieCtrlRegs.PIEACK.bit.ACK3 = 1; // EPWM4 ���ͷ�Ʈ ���Ͱ� ���Ե� CPU ���ͷ�Ʈ Ȯ��׷� 3���� Acknowledge ��Ʈ Ŭ����
    DINT;
    PieCtrlRegs.PIEIER3.all = TempPIEIER;
}

// AC 60hz(16ms)��. 30kW�� 50us�� �����ؼ�, 20ms/50us=320���ε�, AC 1�ֱ⸦ 320���� ���ø��ϴ°���.(60kHz�� ��������� 50khz�� ����������?)
// ���� 100us�� �ϸ� 160��, 50hz�� �ϸ� 200����. �̷��� ���ش��� ���������� �Ǳ��� ����.
// PLL ����ð��� �����ϸ� CLA�� ���� -> 50us�ȿ� CLA���� PLL�� ADC ���͸� ��길 ó�����ְ�, �������� CPU1���� ó�����ָ� 30kW�� ������ �ذ��� �� ����.
__interrupt void CPU_TIMER0_ISR(void)			// 100us timer
{
    // ��ø ���ͷ�Ʈ ���(�߿䵵�� ���� ���� �߿� �� �߿��� ���ͷ�Ʈ�� �ް� ���� ��)
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER1.all;
    IER |= M_INT1;
    IER &= MINT1;	  	               			// Set "global" priority
    PieCtrlRegs.PIEIER1.all &= MG1_7;   		// Set "group"  priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;   			// Enable PIE interrupts
    EINT;                                       // ��ø ���ͷ�Ʈ ���

    // ���ͷ�Ʈ ���� �߿��� Ÿ�̸� ī�������� ����
    // 100us�ȿ� ����� ó�� ����(PLL)�� ���� ó������ ���ϰ�, �ٽ� Ÿ�̸� ���ͷ�Ʈ �߻��ϸ� ������ ���� ����
    CpuTimer0Regs.TCR.bit.TSS = 1; 				// Timer0 stop

    SwtIsr1msCnt++;

    CpuTimer0Regs.TCR.bit.TSS = 0;              // Timer0 start
    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;    // PIE�׷�1 ���ͷ�Ʈ ack ����
    DINT;

    // Single phase PLL(2-Phase)
    if (theta_run == 1)
    {
        V_RT = V_AC;
        V_ds_S_angle = V_RT;

        // All-pass filter
        phase_angle_rad = PI * phase_angle / 360.;
        cutoff_freq = VAC_freq / tan(phase_angle_rad);
        A_inv = (cutoff_freq * PI * 2. * C_TSAMP) + 2.;
        B_inv = (cutoff_freq * PI * 2. * C_TSAMP) - 2.;

        V_qs_S_angle = (B_inv / A_inv) * V_ds_S_angle + V_ds_S_angle_old - (B_inv / A_inv) * V_qs_S_angle_old;
        V_ds_S_angle_old = V_ds_S_angle;
        V_qs_S_angle_old = V_qs_S_angle;

        //--- theta generation & control ---//V_ds_S_angle
        // Park's Transform
        Vds_S_angle = V_ds_S_angle;
        Vqs_S_angle = V_qs_S_angle;

        Vde = sin(Theta_V2L) * Vds_S_angle - cos(Theta_V2L) * Vqs_S_angle; // V2L
        Vqe = cos(Theta_V2L) * Vds_S_angle + sin(Theta_V2L) * Vqs_S_angle; // V2L

        Vde_S_angle = rCOS * Vds_S_angle + rSIN * Vqs_S_angle;
        Vqe_S_angle = -rSIN * Vds_S_angle + rCOS * Vqs_S_angle;

        Vde_S_angleFlt = Kf1_S * Vde_S_angle0 + Kf2_S * Vde_S_angle; // Cutoff freq. = 100Hz
        Vde_S_angle0 = Vde_S_angle;

        Vde_S_angleErr = (Vde_S_angleRef - Vde_S_angleFlt); // VdeAngleRef = 0;

//      We_S_angle = (We_S_angleOld + (KpTheta_S + KiTheta_S * C_TSAMP) * Vde_S_angleErr - KpTheta_S * Vde_S_angleErr0)+ff_theta;
        We_S_angle_I += (KiTheta_S * C_TSAMP) * Vde_S_angleErr;
        We_S_angle_P = KpTheta_S * Vde_S_angleErr0;
        We_S_angle = We_S_angle_P + We_S_angle_I + ff_theta;

//      We_S_angleOld = We_S_angle;
        Vde_S_angleErr0 = Vde_S_angleErr;
        //
        rtheta += We_S_angle * C_TSAMP;
        //   Theta2 += 2*We_S_angle * C_TSAMP;

        //////////////////////////////////////////////////////////////////
        if (rtheta > 2.0 * PI)
        {
            rtheta = 0;
            //Theta = Theta - 2.0 * PI;
        }

        if (rtheta < 0.0)
        {
            rtheta = 0;
            //Theta = Theta + 2.0 * PI;
        }

        rSIN = sin(rtheta);
        rCOS = cos(rtheta);

        theta_count++;

        if (theta_count > 50000)
        {
            theta_count = 0;
        }
    }

//    CpuTimer0Regs.TCR.bit.TSS = 0;              // Timer0 start
//    PieCtrlRegs.PIEACK.all |= PIEACK_GROUP1;    // PIE�׷�1 ���ͷ�Ʈ ack ����
//    DINT;
    PieCtrlRegs.PIEIER1.all = TempPIEIER;
}

void protection(void)
{

}
/*
 __interrupt void ISR_TRIP_ZONE6(void)
 {
 BitSet(lFaultStatus, FLT_HW_OC_BOOST);
 LED2_ON;
 wCntTripZone6++;
 }

 __interrupt void ISR_TRIP_ZONE7(void)
 {
 BitSet(lFaultStatus, FLT_HW_OC_GRID);
 LED3_ON;
 wCntTripZone7++;
 }

 __interrupt void ISR_TRIP_ZONE8(void)
 {
 BitSet(lFaultStatus, FLT_HW_FLT);
 LED3_ON;
 wCntTripZone8++;
 }
 */

void OutputControl(void)
{
    switch (Mode_Select)
    {
    case Openloop:
        break; //Openloop_Theta();
    case Grid:
        break; //PLL_Cal();
        //default :			ControlMode = STOP;		break;
    }

    if (ControlMode == Debuger)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = TestDuty;
        EPwm7Regs.CMPA.bit.CMPA = TestDuty;
        EPwm8Regs.CMPA.bit.CMPA = TestDuty;
    }

    else if (ControlMode == Inverter_Openloop)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = 0;
        EPwm7Regs.CMPA.bit.CMPA = (unsigned int) (Vref + PWM_PRD_half_INV);	// 201026 Bipolar for test sghan
        EPwm8Regs.CMPA.bit.CMPA = (unsigned int) (Vref + PWM_PRD_half_INV);	// 201026 Bipolar for test sghan
    }

    else if (ControlMode == Boost_Openloop)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = (unsigned int) rVboostDuty;
        EPwm7Regs.CMPA.bit.CMPA = 0;
        EPwm8Regs.CMPA.bit.CMPA = 0;
    }

    else if (ControlMode == Inverter_Closedloop)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = 0;
        EPwm7Regs.CMPA.bit.CMPA = (unsigned int) (rPWM6_Ref + PWM_PRD_half_INV);// 201026 Bipolar for test sghan
        EPwm8Regs.CMPA.bit.CMPA = (unsigned int) (rPWM6_Ref + PWM_PRD_half_INV);// 201026 Bipolar for test sghan
    }

    else if (ControlMode == Boost_Closedloop)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = (unsigned int) rRef_IBoost;
        EPwm7Regs.CMPA.bit.CMPA = 0;
        EPwm8Regs.CMPA.bit.CMPA = 0;
    }

    else if (ControlMode == Boost_Inverter)
    {
        PWM_ENB;
        EPwm6Regs.CMPA.bit.CMPA = (unsigned int) rVboostDuty; //rRef_IBoost;

        if (Inverter_Start == 1)
        {
            //	PWM_ENB;
            EPwm7Regs.CMPA.bit.CMPA = (unsigned int) (Vref + PWM_PRD_half_INV);
            EPwm8Regs.CMPA.bit.CMPA = (unsigned int) (_Vref + PWM_PRD_half_INV);
        }

        else
        {
            EPwm7Regs.CMPA.bit.CMPA = 0;
            EPwm8Regs.CMPA.bit.CMPA = 0;
        }
    }
}

/*
 void Openloop_Theta(void)
 {
 Theta+= PI2 * 60 * PWM_Ts;

 if(Theta> PI2)			Theta = 0;

 rSIN = sin(Theta);
 rCOS = cos(Theta);
 }
 */
/*
 void PLL_Cal(void)
 {
 // APF �̿��ؼ� ���� 90�� ���� : Cutoff ���ļ� : 60Hz
 AllPassFilter(rVIN_AC, rVIN_AC_phase, sampleFreq, CutOffFreq_APF, Vac_in_old, Vac_out_old);		// PLL

 // alpha, beta
 rVdss = rVIN_AC;
 rVqss = rVIN_AC_phase;

 LPF(rVdss, rVdss_LPF, rVdss_outold, CutOffFreq_AD, PWM_Ts);
 LPF(rVqss, rVqss_LPF, rVqss_outold, CutOffFreq_AD, PWM_Ts);

 // dq ��ȯ
 AB_TO_DQ(rVdss_LPF, rVqss_LPF, rVdse, rVqse, rSIN2, rCOS2);

 LPF(rVdse, rVdse_LPF, rVdse_outold, VdseCutoff, PWM_Ts);

 //	rVdse = rSIN2(Theta2) * rVdss_LPF - rCOS2(Theta2) * rVqss_LPF;
 //	rVqse = rCOS2(Theta2) * rVdss_LPF + rSIN2(Theta2) * rVqss_LPF;

 // PLL
 PLL(rErrVqse, rVqseRef, rVqse, rVqseErrPterm, rVqseErrIterm, rVKpPLL, rVKiPLL, PWM_Ts, 400, -400, rVqseRefOut, 377, Theta, Theta2, ThetaOffset, rSIN2, rCOS2);
 }
 */ /////21.09.09. revised by SD
void DebugerMode(void)
{
    if (TestDuty >= PWM_PRD_Boost || TestDuty >= PWM_PRD_INV)
        TestDuty = 500;
}
/*
 void openloop_Inverter(void)
 {
 if(Ma <= 0)			Ma = 0;
 else if(Ma >= 1)	Ma = 1;

 Vref = rSIN * PWM_PRD_half_INV * Ma;
 _Vref = -(rSIN) * PWM_PRD_half_INV * Ma;
 }
 */ ////revised by SD 21.09.09
void openloop_Boost(void)
{
    if (rBoostDuty < 0)    rBoostDuty = 0;
    if (rBoostDuty > 0.3)  rBoostDuty = 0.3;
    rVboostDuty = rBoostDuty * 833;
}

void BoostCal(void)
{
    // Ramp �Լ�
    Ramp_Step(V_ref, rRamp_step, PWM_Ts, time);
    Ramp_function(V_ref, rNowValue, rRamp_step, SET_OVT_BOOST_LEVEL, rVDC_INLPF_L);

    //Feedfoward �߰�
    //Boost_FF(rNowValue, rVDC_INLPF_L, P_Duty, P_Ref, PWM_PRD_Boost);

    PI_Control_Cnt++;

    // ���� �����
    if ((PI_Control_Cnt % 5) == 0)
    {
        PI_Control(rErr_VBoost, rNowValue, rVDC_BOOSTLPF, rPterm_VBoost,
                   rIterm_VBoost, rRef_VBoost, 0, 25, -25, rKp_VBoost,
                   rKi_VBoost, PWM_Ts);
        PI_Control_Cnt = 0;
    }

    // ���� �����
    PI_Control(rErr_IBoost, rRef_VBoost, rCURR_BOOSTLPF, rPterm_IBoost,
               rIterm_IBoost, rRef_IBoost, P_Ref, 700, -700, rKp_IBoost,
               rKi_IBoost, PWM_Ts);
}
unsigned int ttttttttt = 1;
/*
 void Curr_Cal(void)
 {

 AllPassFilter(rCURR_AC, rCURR_AC_phase, sampleFreq, CutOffFreq_APF, Iac_in_old, Iac_out_old);		// ���������

 rIdss = rCURR_AC;
 rIqss = rCURR_AC_phase;

 //	LPF(rIdss, rIdss_LPF, rIdss_outold, CutOffFreq_AD, PWM_Ts);
 //	LPF(rIqss, rIqss_LPF, rIqss_outold, CutOffFreq_AD, PWM_Ts);

 AB_TO_DQ(rIdss, rIqss, rIdse, rIqse, rSIN, rCOS);

 PI_Control(rErrIdse, rIdseRef, rIdse, rIdseErrPterm, rIdseErrIterm, rIdseRefOut, 0, TB_inveterPRD, -TB_inveterPRD, rCurKpd, rCurKid, PWM_Ts);
 PI_Control(rErrIqse, rIqseRef, rIqse, rIqseErrPterm, rIqseErrIterm, rIqseRefOut, 0, TB_inveterPRD, -TB_inveterPRD, rCurKpq, rCurKiq, PWM_Ts);

 DQ_TO_AB(rIdseRefOut, rIqseRefOut, rId_alpha, rIq_beta, rSIN, rCOS);

 //	rPwmScaleFactor = rId_alpha * TB_inveterPRD/(2*rVdcScaleLPF);

 rPWM6_Ref = rId_alpha;
 */
/*
 if((Theta2 >= 0.004166) || (Controlflag == 1))
 {
 Controlflag = 1;
 ttttttttt = 0;

 AllPassFilter(rCURR_AC, rCURR_AC_phase, sampleFreq, CutOffFreq_APF, Iac_in_old, Iac_out_old);		// ���������

 rIdss = rCURR_AC;
 rIqss = rCURR_AC_phase;

 LPF(rIdss, rIdss_LPF, rIdss_outold, CutOffFreq_AD, PWM_Ts);
 LPF(rIqss, rIqss_LPF, rIqss_outold, CutOffFreq_AD, PWM_Ts);

 AB_TO_DQ(rIdss_LPF, rIqss_LPF, rIdse, rIqse, rSIN2, rCOS2);

 //		rIdse = rSIN2(Theta2) * rIdss_LPF - rCOS2(Theta2) * rIqss_LPF;
 //		rIqse = rCOS2(Theta2) * rIdss_LPF + rSIN2(Theta2) * rIqss_LPF;

 PI_Control(rErrIdse, rIdseRef, rIdse, rIdseErrPterm, rIdseErrIterm, rIdseRefOut, rVdse_LPF, TB_inveterPRD, -TB_inveterPRD, rCurKpd, rCurKid, PWM_Ts);
 PI_Control(rErrIqse, rIqseRef, rIqse, rIqseErrPterm, rIqseErrIterm, rIqseRefOut, 0, TB_inveterPRD, -TB_inveterPRD, rCurKpq, rCurKiq, PWM_Ts);

 DQ_TO_AB(rIdseRefOut, rIqseRefOut, rId_alpha, rIq_beta, rSIN2, rCOS2);

 //		rId_alpha = rSIN2(Theta2) * rIdseRefOut + rCOS2(Theta2) * rIqseRefOut;
 //		rIq_beta  = -(rCOS2(Theta2) * rIdseRefOut) + rSIN2(Theta2) * rIqseRefOut;

 rPwmScaleFactor = rId_alpha * TB_inveterPRD/(2*rVdcScaleLPF);

 rPWM6_Ref = rPwmScaleFactor;
 }
 // 	ttttttttt = 1;
 }
 */
/*
 void BoostInverterCal(void)
 {

 // Ramp �Լ�
 Ramp_Step(V_ref, rRamp_step, PWM_Ts, time);
 Ramp_function(V_ref, rNowValue, rRamp_step, SET_OVT_BOOST_LEVEL, rVDC_INLPF_L);

 //Feedfoward �߰�
 //Boost_FF(rNowValue, rVDC_INLPF_L, P_Duty, P_Ref, PWM_PRD_Boost);

 PI_Control_Cnt++;

 // ���� �����
 if((PI_Control_Cnt % 5) == 0)
 {
 PI_Control(rErr_VBoost, rNowValue, rVDC_BOOSTLPF, rPterm_VBoost, rIterm_VBoost, rRef_VBoost, 0, 25, -25, rKp_VBoost, rKi_VBoost, PWM_Ts);
 PI_Control_Cnt = 0;
 }

 // ���� �����
 PI_Control(rErr_IBoost, rRef_VBoost, rCURR_BOOSTLPF, rPterm_IBoost, rIterm_IBoost, rRef_IBoost, P_Ref, 400, -400, rKp_IBoost, rKi_IBoost, PWM_Ts);


 if(rBoostDuty < 0) rBoostDuty = 0;
 if(rBoostDuty > 0.4) rBoostDuty = 0.4;
 rVboostDuty = rBoostDuty * 833;

 if(Inverter_Start == 1)
 {
 if(Ma <= 0)			Ma = 0;
 else if(Ma >= 1)	Ma = 1;
 Vref = rSIN * PWM_PRD_half_INV * Ma;
 _Vref = -(rSIN) * PWM_PRD_half_INV * Ma;
 }

 else
 {
 EPwm7Regs.CMPA.bit.CMPA = 0;
 EPwm8Regs.CMPA.bit.CMPA = 0;
 }
 }
 */ //////Revised by SD 21.09.09
void PRController(void)
{
    /*	if(bHarComp3 == TRUE)
     {
     UpdateResoGain(&rCoffHar3ThGain, 3, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic3Th, &rCoffHar3ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic3Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic3Th);
     */
    /*
     if(bHarComp5 == TRUE)
     {
     UpdateResoGain(&rCoffHar5ThGain, 5, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic5Th, &rCoffHar5ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic5Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic5Th);

     if(bHarComp7 == TRUE)
     {
     UpdateResoGain(&rCoffHar7ThGain, 7, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic7Th, &rCoffHar7ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic7Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic7Th);

     if(bHarComp9 == TRUE)
     {
     UpdateResoGain(&rCoffHar9ThGain, 9, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic9Th, &rCoffHar9ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic9Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic9Th);

     if(bHarComp11 == TRUE)
     {
     UpdateResoGain(&rCoffHar11ThGain, 11, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic11Th, &rCoffHar11ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic11Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic11Th);

     if(bHarComp13 == TRUE)
     {
     UpdateResoGain(&rCoffHar13ThGain, 13, rWeGridLPF, PWM_Ts);
     ExcuteReso(&rCoffHarmonic13Th, &rCoffHar13ThGain, rCURR_AC);
     LIMIT(rCoffHarmonic13Th.Ref, -HAR_LIMIT, HAR_LIMIT);
     }

     else	InitResoVariable(&rCoffHarmonic13Th);
     */
}

void CMD_STOP(void)
{
    PWM_BLK;
    //RLY_OFF;
    LED1_ON;
    vari_reset();
    ControlMode = Ready;
    //Mode_Select = 0;
}

void Fault_Clear(void)
{
    lFaultStatus = 0x00000000;
    wCntTripZone6 = 0;
    wCntTripZone7 = 0;
    wCntTripZone8 = 0;
    FaultReset = 0;
    Inverter_Start = 0;
    ControlMode = Ready;
    Trip_CLR;
    LED1_OFF;
    LED2_OFF;
}

interrupt void EPwmIsr(void)
{
    volatile Uint16 TempPIEIER = PieCtrlRegs.PIEIER3.all;
    IER |= M_INT3;
    IER &= MINT3;                       // Set "global" priority
    PieCtrlRegs.PIEIER3.all &= MG3_4;   // Set "group"  priority
    PieCtrlRegs.PIEACK.all = 0xFFFF;    // Enable PIE interrupts
    EINT;

    wPwmIsrCnt++;    // ���ͷ�Ʈ ���� ��ƾ ȣ��Ƚ�� Ȯ�ο� ī����

    PWM_ENB; // pwm buffer on
    EPwm1Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm2Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm3Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm4Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;

    EPwm6Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm7Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm9Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm10Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;

    EPwm11Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm12Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;
    EPwm13Regs.CMPA.bit.CMPA = (int) Test_TBPRD * 0.5;

    EPwm4Regs.ETCLR.bit.INT = 1;     // ePWM ���ͷ�Ʈ �÷��� Ŭ����
    PieCtrlRegs.PIEACK.bit.ACK3 = 1; // EPWM4 ���ͷ�Ʈ ���Ͱ� ���Ե� CPU ���ͷ�Ʈ Ȯ��׷� 3���� Acknowledge ��Ʈ Ŭ����
    DINT;
    PieCtrlRegs.PIEIER3.all = TempPIEIER;
}


// ���ο� ADC ���� �迭�� ���������� �����ϴ� �Լ�
void update_adc_samples(float *adc_avg, float new_value, int *write_index)
{
    adc_avg[*write_index] = new_value;
    *write_index = (*write_index + 1) % NUM_SAMPLES; // �ε��� ��ȯ
}

// �ּ�/�ִ밪�� �����ϰ� ��� ���
float calculate_filtered_average(float *adc_samples, int num_samples)
{
    int j;
    float sum=0.0;
    float average=0.0;
    float min_value;
    float max_value;

    min_value = adc_samples[0];
    max_value = adc_samples[0];

    // min, max search
    for (j = 0; j < num_samples; j++) {
        if (adc_samples[j] < min_value) {
            min_value = adc_samples[j];
        }
        else if (adc_samples[j] > max_value) {
            max_value = adc_samples[j];
        }
    }

    //�ּҰ��� �ִ밪�� ������ ������ ������ �� ���
    for (j = 0; j < num_samples; j++) {
        if (adc_samples[j] != min_value && adc_samples[j] != max_value) {
            sum += adc_samples[j];
        }
    }

    average = sum / (num_samples - 2);

    return average;
}

// ����Ʈ ��� ���� �ڵ�(PFC ������)
void BurstMode(void)
{
    if(Burst_Mode == 1) // burst on�̸�,
    {
        if(DC_link_V > SET_BURST_HI_LEVEL) // DC ������ upper limit �ʰ� ��,
        {
            Flag_BM_Hi_Limit = 1; // limit flag on
            Flag_BM_Lo_Limit = 0;
        }
        if((Flag_BM_Hi_Limit == 1) && (DC_link_V < SET_BURST_LO_LEVEL)) // DC ������ below limit ���� ������,
        {
            Flag_BM_Hi_Limit = 0;
            Flag_BM_Lo_Limit = 1; // flag on
        }

        if(Flag_BM_Hi_Limit == 1)   BM_Pwm_Block = 1; // ����Ī off
        if(Flag_BM_Lo_Limit == 1)   BM_Pwm_Block = 0; // ����Ī on
    }
    else // burst off��,
    {
        Flag_BM_Hi_Limit = 0;
        Flag_BM_Lo_Limit = 0;
        BM_Pwm_Block = 0;
    }
}
